(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        m = ca(this),
        n = function(a, b) {
            if (b) a: {
                var c = m;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    n("Symbol", function(a) {
        if (a) return a;
        var b = function(e, g) {
            this.g = e;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = 0,
            d = function(e) {
                if (this instanceof d) throw new TypeError("Symbol is not a constructor");
                return new b("jscomp_symbol_" + (e || "") + "_" + c++, e)
            };
        return d
    });
    n("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = m[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return da(aa(this))
                }
            })
        }
        return a
    });
    var da = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        ea = function(a) {
            var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
            return b ? b.call(a) : {
                next: aa(a)
            }
        },
        fa = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ja;
    if ("function" == typeof Object.setPrototypeOf) ja = Object.setPrototypeOf;
    else {
        var ka;
        a: {
            var la = {
                    a: !0
                },
                ma = {};
            try {
                ma.__proto__ = la;
                ka = ma.a;
                break a
            } catch (a) {}
            ka = !1
        }
        ja = ka ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var na = ja,
        oa = function(a, b) {
            a.prototype = fa(b.prototype);
            a.prototype.constructor = a;
            if (na) na(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.I = b.prototype
        },
        pa = function() {
            this.j = !1;
            this.h = null;
            this.m = void 0;
            this.g = 1;
            this.o = 0;
            this.i = null
        },
        qa = function(a) {
            if (a.j) throw new TypeError("Generator is already running");
            a.j = !0
        };
    pa.prototype.l = function(a) {
        this.m = a
    };
    var ra = function(a, b) {
        a.i = {
            da: b,
            la: !0
        };
        a.g = a.o
    };
    pa.prototype.return = function(a) {
        this.i = {
            return: a
        };
        this.g = this.o
    };
    var r = function(a, b, c) {
            a.g = c;
            return {
                value: b
            }
        },
        sa = function(a) {
            this.g = new pa;
            this.h = a
        },
        va = function(a, b) {
            qa(a.g);
            var c = a.g.h;
            if (c) return ta(a, "return" in c ? c["return"] : function(d) {
                return {
                    value: d,
                    done: !0
                }
            }, b, a.g.return);
            a.g.return(b);
            return ua(a)
        },
        ta = function(a, b, c, d) {
            try {
                var e = b.call(a.g.h, c);
                if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
                if (!e.done) return a.g.j = !1, e;
                var g = e.value
            } catch (f) {
                return a.g.h = null, ra(a.g, f), ua(a)
            }
            a.g.h = null;
            d.call(a.g, g);
            return ua(a)
        },
        ua = function(a) {
            for (; a.g.g;) try {
                var b = a.h(a.g);
                if (b) return a.g.j = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.g.m = void 0, ra(a.g, c)
            }
            a.g.j = !1;
            if (a.g.i) {
                b = a.g.i;
                a.g.i = null;
                if (b.la) throw b.da;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        Ba = function(a) {
            this.next = function(b) {
                qa(a.g);
                a.g.h ? b = ta(a, a.g.h.next, b, a.g.l) : (a.g.l(b), b = ua(a));
                return b
            };
            this.throw = function(b) {
                qa(a.g);
                a.g.h ? b = ta(a, a.g.h["throw"], b, a.g.l) : (ra(a.g, b), b = ua(a));
                return b
            };
            this.return = function(b) {
                return va(a, b)
            };
            this[Symbol.iterator] =
                function() {
                    return this
                }
        },
        Ca = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function g(f) {
                    f.done ? d(f.value) : Promise.resolve(f.value).then(b, c).then(g, e)
                }
                g(a.next())
            })
        },
        t = function(a) {
            return Ca(new Ba(new sa(a)))
        };
    n("Promise", function(a) {
        function b() {
            this.g = null
        }

        function c(f) {
            return f instanceof e ? f : new e(function(h) {
                h(f)
            })
        }
        if (a) return a;
        b.prototype.h = function(f) {
            if (null == this.g) {
                this.g = [];
                var h = this;
                this.i(function() {
                    h.l()
                })
            }
            this.g.push(f)
        };
        var d = m.setTimeout;
        b.prototype.i = function(f) {
            d(f, 0)
        };
        b.prototype.l = function() {
            for (; this.g && this.g.length;) {
                var f = this.g;
                this.g = [];
                for (var h = 0; h < f.length; ++h) {
                    var k = f[h];
                    f[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.j(l)
                    }
                }
            }
            this.g = null
        };
        b.prototype.j = function(f) {
            this.i(function() {
                throw f;
            })
        };
        var e = function(f) {
            this.g = 0;
            this.i = void 0;
            this.h = [];
            this.o = !1;
            var h = this.j();
            try {
                f(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.j = function() {
            function f(l) {
                return function(q) {
                    k || (k = !0, l.call(h, q))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: f(this.A),
                reject: f(this.l)
            }
        };
        e.prototype.A = function(f) {
            if (f === this) this.l(new TypeError("A Promise cannot resolve to itself"));
            else if (f instanceof e) this.C(f);
            else {
                a: switch (typeof f) {
                    case "object":
                        var h = null != f;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ?
                this.v(f) : this.m(f)
            }
        };
        e.prototype.v = function(f) {
            var h = void 0;
            try {
                h = f.then
            } catch (k) {
                this.l(k);
                return
            }
            "function" == typeof h ? this.D(h, f) : this.m(f)
        };
        e.prototype.l = function(f) {
            this.s(2, f)
        };
        e.prototype.m = function(f) {
            this.s(1, f)
        };
        e.prototype.s = function(f, h) {
            if (0 != this.g) throw Error("Cannot settle(" + f + ", " + h + "): Promise already settled in state" + this.g);
            this.g = f;
            this.i = h;
            2 === this.g && this.B();
            this.u()
        };
        e.prototype.B = function() {
            var f = this;
            d(function() {
                    if (f.H()) {
                        var h = m.console;
                        "undefined" !== typeof h && h.error(f.i)
                    }
                },
                1)
        };
        e.prototype.H = function() {
            if (this.o) return !1;
            var f = m.CustomEvent,
                h = m.Event,
                k = m.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof f ? f = new f("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? f = new h("unhandledrejection", {
                cancelable: !0
            }) : (f = m.document.createEvent("CustomEvent"), f.initCustomEvent("unhandledrejection", !1, !0, f));
            f.promise = this;
            f.reason = this.i;
            return k(f)
        };
        e.prototype.u = function() {
            if (null != this.h) {
                for (var f = 0; f < this.h.length; ++f) g.h(this.h[f]);
                this.h = null
            }
        };
        var g = new b;
        e.prototype.C = function(f) {
            var h = this.j();
            f.L(h.resolve, h.reject)
        };
        e.prototype.D = function(f, h) {
            var k = this.j();
            try {
                f.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(f, h) {
            function k(v, B) {
                return "function" == typeof v ? function(H) {
                    try {
                        l(v(H))
                    } catch (N) {
                        q(N)
                    }
                } : B
            }
            var l, q, O = new e(function(v, B) {
                l = v;
                q = B
            });
            this.L(k(f, l), k(h, q));
            return O
        };
        e.prototype.catch = function(f) {
            return this.then(void 0, f)
        };
        e.prototype.L = function(f, h) {
            function k() {
                switch (l.g) {
                    case 1:
                        f(l.i);
                        break;
                    case 2:
                        h(l.i);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.g);
                }
            }
            var l = this;
            null == this.h ? g.h(k) : this.h.push(k);
            this.o = !0
        };
        e.resolve = c;
        e.reject = function(f) {
            return new e(function(h, k) {
                k(f)
            })
        };
        e.race = function(f) {
            return new e(function(h, k) {
                for (var l = ea(f), q = l.next(); !q.done; q = l.next()) c(q.value).L(h, k)
            })
        };
        e.all = function(f) {
            var h = ea(f),
                k = h.next();
            return k.done ? c([]) : new e(function(l, q) {
                function O(H) {
                    return function(N) {
                        v[H] = N;
                        B--;
                        0 == B && l(v)
                    }
                }
                var v = [],
                    B = 0;
                do v.push(void 0), B++, c(k.value).L(O(v.length - 1), q), k = h.next();
                while (!k.done)
            })
        };
        return e
    });
    n("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            if (null == this) throw new TypeError("The 'this' value for String.prototype.startsWith must not be null or undefined");
            if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.startsWith must not be a regular expression");
            var d = this + "";
            b += "";
            var e = d.length,
                g = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var f = 0; f < g && c < e;)
                if (d[c++] != b[f++]) return !1;
            return f >= g
        }
    });
    n("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    var Da = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var g = c++;
                        return {
                            value: b(g, a[g]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    n("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Da(this, function(b) {
                return b
            })
        }
    });
    n("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Da(this, function(b, c) {
                return [b, c]
            })
        }
    });
    var Ea = Ea || {},
        u = this || self,
        Fa = function() {},
        Ga = function(a) {
            var b = typeof a;
            return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        Ha = function(a) {
            var b = typeof a;
            return "object" == b && null != a || "function" == b
        },
        Ia = function(a, b, c) {
            return a.call.apply(a.bind, arguments)
        },
        Ja = function(a, b, c) {
            if (!a) throw Error();
            if (2 < arguments.length) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b, e)
                }
            }
            return function() {
                return a.apply(b,
                    arguments)
            }
        },
        w = function(a, b, c) {
            Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? w = Ia : w = Ja;
            return w.apply(null, arguments)
        },
        Ka = function(a, b) {
            a = a.split(".");
            var c = u;
            a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        },
        x = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.I = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.oa =
                function(d, e, g) {
                    for (var f = Array(arguments.length - 2), h = 2; h < arguments.length; h++) f[h - 2] = arguments[h];
                    return b.prototype[e].apply(d, f)
                }
        },
        La = function(a) {
            return a
        };

    function Ma(a) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Ma);
        else {
            var b = Error().stack;
            b && (this.stack = b)
        }
        a && (this.message = String(a))
    }
    x(Ma, Error);
    Ma.prototype.name = "CustomError";
    var Na;
    var Oa = function(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Ma.call(this, c + a[d])
    };
    x(Oa, Ma);
    Oa.prototype.name = "AssertionError";
    var Pa = function(a, b, c, d) {
            var e = "Assertion failed";
            if (c) {
                e += ": " + c;
                var g = d
            } else a && (e += ": " + a, g = b);
            throw new Oa("" + e, g || []);
        },
        y = function(a, b, c) {
            a || Pa("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Qa = function(a, b) {
            throw new Oa("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        Ra = function(a, b, c) {
            "number" !== typeof a && Pa("Expected number but got %s: %s.", [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        };
    var Sa = Array.prototype.indexOf ? function(a, b) {
            y(null != a.length);
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        Ta = Array.prototype.forEach ? function(a, b, c) {
            y(null != a.length);
            Array.prototype.forEach.call(a, b, c)
        } : function(a, b, c) {
            for (var d = a.length, e = "string" === typeof a ? a.split("") : a, g = 0; g < d; g++) g in e && b.call(c, e[g], g, a)
        };

    function gb(a) {
        a: {
            var b = hb;
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function ib(a, b) {
        b = Sa(a, b);
        var c;
        if (c = 0 <= b) y(null != a.length), Array.prototype.splice.call(a, b, 1);
        return c
    }

    function jb(a) {
        return Array.prototype.concat.apply([], arguments)
    };
    var kb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" "),
        lb = function(a, b) {
            for (var c, d, e = 1; e < arguments.length; e++) {
                d = arguments[e];
                for (c in d) a[c] = d[c];
                for (var g = 0; g < kb.length; g++) c = kb[g], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
            }
        };
    var mb;
    var z = function(a, b) {
        this.i = a === nb && b || "";
        this.j = ob
    };
    z.prototype.h = !0;
    z.prototype.g = function() {
        return this.i
    };
    z.prototype.toString = function() {
        return "Const{" + this.i + "}"
    };
    var pb = function(a) {
            if (a instanceof z && a.constructor === z && a.j === ob) return a.i;
            Qa("expected object of type Const, got '" + a + "'");
            return "type_error:Const"
        },
        ob = {},
        nb = {};
    var A = function(a, b) {
        this.i = b === qb ? a : ""
    };
    A.prototype.h = !0;
    A.prototype.g = function() {
        return this.i.toString()
    };
    A.prototype.toString = function() {
        return this.i + ""
    };
    var ub = function(a, b) {
            var c = pb(a);
            if (!rb.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
            a = c.replace(sb, function(d, e) {
                if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
                d = b[e];
                return d instanceof z ? pb(d) : encodeURIComponent(String(d))
            });
            return tb(a)
        },
        sb = /%{(\w+)}/g,
        rb = /^((https:)?\/\/[0-9a-z.:[\]-]+\/|\/[^/\\]|[^:/\\%]+\/|[^:/\\%]*[?#]|about:blank#)/i,
        vb = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        xb = function(a, b, c) {
            a = ub(a, b);
            a instanceof A && a.constructor === A ? a = a.i : (Qa("expected object of type TrustedResourceUrl, got '" + a + "' of type " + Ga(a)), a = "type_error:TrustedResourceUrl");
            a = vb.exec(a.toString());
            b = a[3] || "";
            return tb(a[1] + wb("?", a[2] || "", c) + wb("#", b, void 0))
        },
        qb = {},
        tb = function(a) {
            if (void 0 === mb) {
                var b = null;
                var c = u.trustedTypes;
                if (c && c.createPolicy) {
                    try {
                        b = c.createPolicy("goog#html", {
                            createHTML: La,
                            createScript: La,
                            createScriptURL: La
                        })
                    } catch (d) {
                        u.console && u.console.error(d.message)
                    }
                    mb = b
                } else mb =
                    b
            }
            a = (b = mb) ? b.createScriptURL(a) : a;
            return new A(a, qb)
        },
        wb = function(a, b, c) {
            if (null == c) return b;
            if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
            for (var d in c)
                if (Object.prototype.hasOwnProperty.call(c, d)) {
                    var e = c[d];
                    e = Array.isArray(e) ? e : [e];
                    for (var g = 0; g < e.length; g++) {
                        var f = e[g];
                        null != f && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(f)))
                    }
                }
            return b
        };
    var yb = String.prototype.trim ? function(a) {
            return a.trim()
        } : function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        C = function(a, b) {
            return -1 != a.indexOf(b)
        },
        zb = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var D = function(a, b) {
        this.i = b === Ab ? a : ""
    };
    D.prototype.h = !0;
    D.prototype.g = function() {
        return this.i.toString()
    };
    D.prototype.toString = function() {
        return this.i.toString()
    };
    var Bb = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        Ab = {};
    var E;
    a: {
        var Cb = u.navigator;
        if (Cb) {
            var Db = Cb.userAgent;
            if (Db) {
                E = Db;
                break a
            }
        }
        E = ""
    };
    var Eb = function(a) {
        Eb[" "](a);
        return a
    };
    Eb[" "] = Fa;
    var Fb = function(a, b) {
            try {
                return Eb(a[b]), !0
            } catch (c) {}
            return !1
        },
        Hb = function(a, b) {
            var c = Gb;
            return Object.prototype.hasOwnProperty.call(c, a) ? c[a] : c[a] = b(a)
        };
    var Ib = C(E, "Opera"),
        Jb = C(E, "Trident") || C(E, "MSIE"),
        Kb = C(E, "Edge"),
        Lb = C(E, "Gecko") && !(C(E.toLowerCase(), "webkit") && !C(E, "Edge")) && !(C(E, "Trident") || C(E, "MSIE")) && !C(E, "Edge"),
        Mb = C(E.toLowerCase(), "webkit") && !C(E, "Edge"),
        Nb = function() {
            var a = u.document;
            return a ? a.documentMode : void 0
        },
        Ob;
    a: {
        var Pb = "",
            Qb = function() {
                var a = E;
                if (Lb) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Kb) return /Edge\/([\d\.]+)/.exec(a);
                if (Jb) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Mb) return /WebKit\/(\S+)/.exec(a);
                if (Ib) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();Qb && (Pb = Qb ? Qb[1] : "");
        if (Jb) {
            var Rb = Nb();
            if (null != Rb && Rb > parseFloat(Pb)) {
                Ob = String(Rb);
                break a
            }
        }
        Ob = Pb
    }
    var Sb = Ob,
        Gb = {},
        Tb = function(a) {
            return Hb(a, function() {
                for (var b = 0, c = yb(String(Sb)).split("."), d = yb(String(a)).split("."), e = Math.max(c.length, d.length), g = 0; 0 == b && g < e; g++) {
                    var f = c[g] || "",
                        h = d[g] || "";
                    do {
                        f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                        h = /(\d*)(\D*)(.*)/.exec(h) || ["", "", "", ""];
                        if (0 == f[0].length && 0 == h[0].length) break;
                        b = zb(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == h[1].length ? 0 : parseInt(h[1], 10)) || zb(0 == f[2].length, 0 == h[2].length) || zb(f[2], h[2]);
                        f = f[3];
                        h = h[3]
                    } while (0 == b)
                }
                return 0 <= b
            })
        },
        Ub;
    if (u.document && Jb) {
        var Vb = Nb();
        Ub = Vb ? Vb : parseInt(Sb, 10) || void 0
    } else Ub = void 0;
    var Wb = Ub;
    Object.freeze && Object.freeze([]);
    var Xb = document;
    var Yb = function(a, b) {
            var c;
            var d = document;
            b = b || d;
            if (b.querySelectorAll && b.querySelector && a) return b.querySelectorAll(a ? "." + a : "");
            if (a && b.getElementsByClassName) {
                var e = b.getElementsByClassName(a);
                return e
            }
            e = b.getElementsByTagName("*");
            if (a) {
                var g = {};
                for (d = c = 0; b = e[d]; d++) {
                    var f = b.className,
                        h;
                    if (h = "function" == typeof f.split) h = 0 <= Sa(f.split(/\s+/), a);
                    h && (g[c++] = b)
                }
                g.length = c;
                return g
            }
            return e
        },
        Zb = function(a) {
            this.g = a || u.document || document
        };
    Zb.prototype.appendChild = function(a, b) {
        y(null != a && null != b, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    var $b = /^(?:([^:/?#.]+):)?(?:\/\/(?:([^\\/?#]*)@)?([^\\/?#]*?)(?::([0-9]+))?(?=[\\/?#]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/,
        ac = function(a, b) {
            if (a) {
                a = a.split("&");
                for (var c = 0; c < a.length; c++) {
                    var d = a[c].indexOf("="),
                        e = null;
                    if (0 <= d) {
                        var g = a[c].substring(0, d);
                        e = a[c].substring(d + 1)
                    } else g = a[c];
                    b(g, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
                }
            }
        };
    var bc = function(a) {
        try {
            return !!a && null != a.location.href && Fb(a, "foo")
        } catch (b) {
            return !1
        }
    };
    var cc = function() {
        this.s = this.s;
        this.A = this.A
    };
    cc.prototype.s = !1;
    cc.prototype.o = function() {
        if (this.A)
            for (; this.A.length;) this.A.shift()()
    };
    var dc = function() {
        var a = void 0 === a ? u : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (c) {}
        try {
            if (b && b.pageViewId && b.canonicalUrl) return b
        } catch (c) {}
        return null
    };
    var ec = {};

    function Cc(a) {
        if (a !== ec) throw Error("Bad secret");
    };

    function Dc() {
        var a = "undefined" !== typeof window ? window.trustedTypes : void 0;
        return null !== a && void 0 !== a ? a : null
    };
    var Ec, Fc = function() {},
        Gc = function(a, b) {
            Cc(b);
            this.g = a
        };
    oa(Gc, Fc);
    Gc.prototype.toString = function() {
        return this.g.toString()
    };
    var Hc = null === (Ec = Dc()) || void 0 === Ec ? void 0 : Ec.emptyHTML;
    new Gc(null !== Hc && void 0 !== Hc ? Hc : "", ec);
    var Ic, Jc = function() {},
        Kc = function(a, b) {
            Cc(b);
            this.g = a
        };
    oa(Kc, Jc);
    Kc.prototype.toString = function() {
        return this.g.toString()
    };
    var Lc = null === (Ic = Dc()) || void 0 === Ic ? void 0 : Ic.emptyScript;
    new Kc(null !== Lc && void 0 !== Lc ? Lc : "", ec);
    var Mc = function() {},
        Nc = function(a, b) {
            Cc(b);
            this.g = a
        };
    oa(Nc, Mc);
    Nc.prototype.toString = function() {
        return this.g
    };
    new Nc("about:blank", ec);
    new Nc("about:invalid#zTSz", ec);
    var Oc = !!window.google_async_iframe_id,
        Pc = Oc && window.parent || window,
        Qc = function() {
            if (Oc && !bc(Pc)) {
                var a = "." + Xb.domain;
                try {
                    for (; 2 < a.split(".").length && !bc(Pc);) Xb.domain = a = a.substr(a.indexOf(".") + 1), Pc = window.parent
                } catch (b) {}
                bc(Pc) || (Pc = window)
            }
            return Pc
        };
    var Rc = function() {
        var a = dc();
        return (a ? bc(a.master) ? a.master : null : null) || Qc()
    };
    var F = navigator,
        Sc = function(a) {
            var b = 1,
                c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        Tc = function(a, b) {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return Sc(a.toLowerCase())
        },
        Uc = /^\s*_ga=\s*1\.(\d+)[^.]*\.(.*?)\s*$/,
        Vc = /^[^=]+=\s*GA1\.(\d+)[^.]*\.(.*?)\s*$/,
        Wc = /^\s*_ga=\s*()(amp-[\w.-]{22,64})$/;
    var Xc = window;
    var Yc = {};
    var Zc = {},
        $c = function() {
            return void 0 == Zc.gtag_cs_api ? !1 : Zc.gtag_cs_api
        };
    var ad = [];

    function bd() {
        var a = {};
        var b = Xc.google_tag_data;
        Xc.google_tag_data = void 0 === b ? a : b;
        a = Xc.google_tag_data;
        a.ics || (a.ics = {
            entries: {},
            set: cd,
            update: dd,
            addListener: ed,
            notifyListeners: fd,
            active: !1,
            usedDefault: !1
        });
        return a.ics
    }

    function cd(a, b, c, d, e, g) {
        var f = bd();
        f.active = !0;
        f.usedDefault = !0;
        if (void 0 != b) {
            var h = f.entries;
            f = h[a] || {};
            var k = f.region;
            c = c && "string" == typeof c ? c.toUpperCase() : void 0;
            d = d.toUpperCase();
            e = e.toUpperCase();
            if (c === e || (c === d ? k !== e : !c && !k)) {
                d = !!(g && 0 < g && void 0 === f.update);
                var l = {
                    region: c,
                    initial: "granted" === b,
                    update: f.update,
                    quiet: d
                };
                h[a] = l;
                d && Xc.setTimeout(function() {
                    h[a] === l && l.quiet && (l.quiet = !1, gd(a), fd(), Yc.TAGGING = Yc.TAGGING || [], Yc.TAGGING[2] = !0)
                }, g)
            }
        }
    }

    function dd(a, b) {
        var c = bd();
        c.active = !0;
        if (void 0 != b) {
            var d = hd(a);
            c = c.entries;
            c = c[a] = c[a] || {};
            c.update = "granted" === b;
            b = hd(a);
            c.quiet ? (c.quiet = !1, gd(a)) : b !== d && gd(a)
        }
    }

    function ed(a, b) {
        ad.push({
            Z: a,
            ea: b
        })
    }

    function gd(a) {
        for (var b = 0; b < ad.length; ++b) {
            var c = ad[b];
            "[object Array]" == Object.prototype.toString.call(Object(c.Z)) && -1 !== c.Z.indexOf(a) && (c.$ = !0)
        }
    }

    function fd(a) {
        for (var b = 0; b < ad.length; ++b) {
            var c = ad[b];
            if (c.$) {
                c.$ = !1;
                try {
                    c.ea({
                        pa: a
                    })
                } catch (d) {}
            }
        }
    }
    var hd = function(a) {
        a = bd().entries[a] || {};
        return void 0 !== a.update ? a.update : void 0 !== a.initial ? a.initial : void 0
    };
    var id = function() {
        if (!$c() || !$c() || !bd().active) return !0;
        if ((bd().entries.ad_storage || {}).quiet) return !1;
        var a = hd("ad_storage");
        return null == a ? !0 : !!a
    };
    var jd = /^~?[\w-]+$/,
        kd = function(a) {
            return a.filter(function(b) {
                return jd.test(b)
            })
        };
    var ld = /^UA-\d+-\d+%3A[\w-]+(?:%2C[\w-]+)*(?:%3BUA-\d+-\d+%3A[\w-]+(?:%2C[\w-]+)*)*$/,
        md = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        nd = /^\d+\.fls\.doubleclick\.net$/,
        od = /;gac=([^;?]+)/,
        pd = /;gclaw=([^;?]+)/;
    var qd = "google_conversion_id google_conversion_format google_conversion_type google_conversion_order_id google_conversion_language google_conversion_value google_conversion_currency google_conversion_domain google_conversion_label google_conversion_color google_disable_viewthrough google_enable_display_cookie_match google_gtag_event_data google_remarketing_only google_conversion_linker google_tag_for_child_directed_treatment google_tag_for_under_age_of_consent google_allow_ad_personalization_signals google_restricted_data_processing google_conversion_items google_conversion_merchant_id google_user_id google_custom_params google_conversion_date google_conversion_time google_conversion_js_version onload_callback opt_image_generator google_gtm_url_processor google_conversion_page_url google_conversion_referrer_url google_gtm google_gcl_cookie_prefix google_read_gcl_cookie_opt_out google_basket_feed_country google_basket_feed_language google_basket_discount google_basket_transaction_type google_additional_conversion_params google_additional_params google_transport_url google_gtm_experiments".split(" ");
    var rd = Object.freeze || function(a) {
        return a
    };
    var sd;
    (sd = !Jb) || (sd = 9 <= Number(Wb));
    var td = sd,
        ud = Jb && !Tb("9"),
        vd = function() {
            if (!u.addEventListener || !Object.defineProperty) return !1;
            var a = !1,
                b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
            try {
                u.addEventListener("test", Fa, b), u.removeEventListener("test", Fa, b)
            } catch (c) {}
            return a
        }();
    var wd = function(a, b) {
        this.type = a;
        this.g = this.target = b;
        this.defaultPrevented = !1
    };
    wd.prototype.h = function() {
        this.defaultPrevented = !0
    };
    var G = function(a, b) {
        wd.call(this, a ? a.type : "");
        this.relatedTarget = this.g = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
        this.key = "";
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.i = null;
        a && this.init(a, b)
    };
    x(G, wd);
    var xd = rd({
        2: "touch",
        3: "pen",
        4: "mouse"
    });
    G.prototype.init = function(a, b) {
        var c = this.type = a.type,
            d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
        this.target = a.target || a.srcElement;
        this.g = b;
        (b = a.relatedTarget) ? Lb && (Fb(b, "nodeName") || (b = null)): "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
        this.relatedTarget = b;
        d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.clientX = void 0 !== a.clientX ? a.clientX :
            a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
        this.button = a.button;
        this.key = a.key || "";
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.pointerId = a.pointerId || 0;
        this.pointerType = "string" === typeof a.pointerType ? a.pointerType : xd[a.pointerType] || "";
        this.state = a.state;
        this.i = a;
        a.defaultPrevented && G.I.h.call(this)
    };
    G.prototype.h = function() {
        G.I.h.call(this);
        var a = this.i;
        if (a.preventDefault) a.preventDefault();
        else if (a.returnValue = !1, ud) try {
            if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) a.keyCode = -1
        } catch (b) {}
    };
    var yd = "closure_listenable_" + (1E6 * Math.random() | 0);
    var zd = 0;
    var Ad = function(a, b, c, d, e) {
            this.listener = a;
            this.g = null;
            this.src = b;
            this.type = c;
            this.capture = !!d;
            this.M = e;
            this.key = ++zd;
            this.G = this.K = !1
        },
        Bd = function(a) {
            a.G = !0;
            a.listener = null;
            a.g = null;
            a.src = null;
            a.M = null
        };
    var Cd = function(a) {
        this.src = a;
        this.g = {};
        this.h = 0
    };
    Cd.prototype.add = function(a, b, c, d, e) {
        var g = a.toString();
        a = this.g[g];
        a || (a = this.g[g] = [], this.h++);
        var f = Dd(a, b, d, e); - 1 < f ? (b = a[f], c || (b.K = !1)) : (b = new Ad(b, this.src, g, !!d, e), b.K = c, a.push(b));
        return b
    };
    var Ed = function(a, b) {
            var c = b.type;
            c in a.g && ib(a.g[c], b) && (Bd(b), 0 == a.g[c].length && (delete a.g[c], a.h--))
        },
        Dd = function(a, b, c, d) {
            for (var e = 0; e < a.length; ++e) {
                var g = a[e];
                if (!g.G && g.listener == b && g.capture == !!c && g.M == d) return e
            }
            return -1
        };
    var Fd = "closure_lm_" + (1E6 * Math.random() | 0),
        Gd = {},
        Hd = 0,
        Jd = function(a, b, c, d, e) {
            if (d && d.once) return Id(a, b, c, d, e);
            if (Array.isArray(b)) {
                for (var g = 0; g < b.length; g++) Jd(a, b[g], c, d, e);
                return null
            }
            c = Kd(c);
            return a && a[yd] ? Ld(a, b, c, Ha(d) ? !!d.capture : !!d, e) : Md(a, b, c, !1, d, e)
        },
        Md = function(a, b, c, d, e, g) {
            if (!b) throw Error("Invalid event type");
            var f = Ha(e) ? !!e.capture : !!e,
                h = Nd(a);
            h || (a[Fd] = h = new Cd(a));
            c = h.add(b, c, d, f, g);
            if (c.g) return c;
            d = Od();
            c.g = d;
            d.src = a;
            d.listener = c;
            if (a.addEventListener) vd || (e = f), void 0 === e &&
                (e = !1), a.addEventListener(b.toString(), d, e);
            else if (a.attachEvent) a.attachEvent(Pd(b.toString()), d);
            else if (a.addListener && a.removeListener) y("change" === b, "MediaQueryList only has a change event"), a.addListener(d);
            else throw Error("addEventListener and attachEvent are unavailable.");
            Hd++;
            return c
        },
        Od = function() {
            var a = Qd,
                b = td ? function(c) {
                    return a.call(b.src, b.listener, c)
                } : function(c) {
                    c = a.call(b.src, b.listener, c);
                    if (!c) return c
                };
            return b
        },
        Id = function(a, b, c, d, e) {
            if (Array.isArray(b)) {
                for (var g = 0; g < b.length; g++) Id(a,
                    b[g], c, d, e);
                return null
            }
            c = Kd(c);
            return a && a[yd] ? a.i.add(String(b), c, !0, Ha(d) ? !!d.capture : !!d, e) : Md(a, b, c, !0, d, e)
        },
        Rd = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var g = 0; g < b.length; g++) Rd(a, b[g], c, d, e);
            else(d = Ha(d) ? !!d.capture : !!d, c = Kd(c), a && a[yd]) ? (a = a.i, b = String(b).toString(), b in a.g && (g = a.g[b], c = Dd(g, c, d, e), -1 < c && (Bd(g[c]), y(null != g.length), Array.prototype.splice.call(g, c, 1), 0 == g.length && (delete a.g[b], a.h--)))) : a && (a = Nd(a)) && (b = a.g[b.toString()], a = -1, b && (a = Dd(b, c, d, e)), (c = -1 < a ? b[a] : null) && Sd(c))
        },
        Sd = function(a) {
            if ("number" !== typeof a && a && !a.G) {
                var b = a.src;
                if (b && b[yd]) Ed(b.i, a);
                else {
                    var c = a.type,
                        d = a.g;
                    b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Pd(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                    Hd--;
                    (c = Nd(b)) ? (Ed(c, a), 0 == c.h && (c.src = null, b[Fd] = null)) : Bd(a)
                }
            }
        },
        Pd = function(a) {
            return a in Gd ? Gd[a] : Gd[a] = "on" + a
        },
        Ud = function(a, b, c, d) {
            var e = !0;
            if (a = Nd(a))
                if (b = a.g[b.toString()])
                    for (b = b.concat(), a = 0; a < b.length; a++) {
                        var g = b[a];
                        g && g.capture == c && !g.G &&
                            (g = Td(g, d), e = e && !1 !== g)
                    }
            return e
        },
        Td = function(a, b) {
            var c = a.listener,
                d = a.M || a.src;
            a.K && Sd(a);
            return c.call(d, b)
        },
        Qd = function(a, b) {
            if (a.G) return !0;
            if (!td) {
                if (!b) a: {
                    b = ["window", "event"];
                    for (var c = u, d = 0; d < b.length; d++)
                        if (c = c[b[d]], null == c) {
                            b = null;
                            break a
                        }
                    b = c
                }
                d = b;
                b = new G(d, this);
                c = !0;
                if (!(0 > d.keyCode || void 0 != d.returnValue)) {
                    a: {
                        var e = !1;
                        if (0 == d.keyCode) try {
                            d.keyCode = -1;
                            break a
                        } catch (f) {
                            e = !0
                        }
                        if (e || void 0 == d.returnValue) d.returnValue = !0
                    }
                    d = [];
                    for (e = b.g; e; e = e.parentNode) d.push(e);a = a.type;
                    for (e = d.length - 1; 0 <=
                        e; e--) {
                        b.g = d[e];
                        var g = Ud(d[e], a, !0, b);
                        c = c && g
                    }
                    for (e = 0; e < d.length; e++) b.g = d[e],
                    g = Ud(d[e], a, !1, b),
                    c = c && g
                }
                return c
            }
            return Td(a, new G(b, this))
        },
        Nd = function(a) {
            a = a[Fd];
            return a instanceof Cd ? a : null
        },
        Vd = "__closure_events_fn_" + (1E9 * Math.random() >>> 0),
        Kd = function(a) {
            y(a, "Listener can not be null.");
            if ("function" === typeof a) return a;
            y(a.handleEvent, "An object listener must have handleEvent method.");
            a[Vd] || (a[Vd] = function(b) {
                return a.handleEvent(b)
            });
            return a[Vd]
        };
    var Wd = function(a) {
            a = String(a);
            if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + a + ")")
            } catch (b) {}
            throw Error("Invalid JSON string: " + a);
        },
        Xd = function() {},
        Fe = function(a, b, c) {
            if (null == b) c.push("null");
            else {
                if ("object" == typeof b) {
                    if (Array.isArray(b)) {
                        var d =
                            b;
                        b = d.length;
                        c.push("[");
                        for (var e = "", g = 0; g < b; g++) c.push(e), Fe(a, d[g], c), e = ",";
                        c.push("]");
                        return
                    }
                    if (b instanceof String || b instanceof Number || b instanceof Boolean) b = b.valueOf();
                    else {
                        c.push("{");
                        e = "";
                        for (d in b) Object.prototype.hasOwnProperty.call(b, d) && (g = b[d], "function" != typeof g && (c.push(e), Ge(d, c), c.push(":"), Fe(a, g, c), e = ","));
                        c.push("}");
                        return
                    }
                }
                switch (typeof b) {
                    case "string":
                        Ge(b, c);
                        break;
                    case "number":
                        c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
                        break;
                    case "boolean":
                        c.push(String(b));
                        break;
                    case "function":
                        c.push("null");
                        break;
                    default:
                        throw Error("Unknown type: " + typeof b);
                }
            }
        },
        He = {
            '"': '\\"',
            "\\": "\\\\",
            "/": "\\/",
            "\b": "\\b",
            "\f": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t",
            "\x0B": "\\u000b"
        },
        Ie = /\uffff/.test("\uffff") ? /[\\"\x00-\x1f\x7f-\uffff]/g : /[\\"\x00-\x1f\x7f-\xff]/g,
        Ge = function(a, b) {
            b.push('"', a.replace(Ie, function(c) {
                var d = He[c];
                d || (d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).substr(1), He[c] = d);
                return d
            }), '"')
        };
    var I = function() {
        cc.call(this);
        this.i = new Cd(this);
        this.aa = this;
        this.P = null
    };
    x(I, cc);
    I.prototype[yd] = !0;
    I.prototype.removeEventListener = function(a, b, c, d) {
        Rd(this, a, b, c, d)
    };
    var J = function(a, b) {
        Je(a);
        var c = a.P;
        if (c) {
            var d = [];
            for (var e = 1; c; c = c.P) d.push(c), y(1E3 > ++e, "infinite loop")
        }
        a = a.aa;
        c = b.type || b;
        "string" === typeof b ? b = new wd(b, a) : b instanceof wd ? b.target = b.target || a : (e = b, b = new wd(c, a), lb(b, e));
        e = !0;
        if (d)
            for (var g = d.length - 1; 0 <= g; g--) {
                var f = b.g = d[g];
                e = Ke(f, c, !0, b) && e
            }
        f = b.g = a;
        e = Ke(f, c, !0, b) && e;
        e = Ke(f, c, !1, b) && e;
        if (d)
            for (g = 0; g < d.length; g++) f = b.g = d[g], e = Ke(f, c, !1, b) && e
    };
    I.prototype.o = function() {
        I.I.o.call(this);
        if (this.i) {
            var a = this.i,
                b = 0,
                c;
            for (c in a.g) {
                for (var d = a.g[c], e = 0; e < d.length; e++) ++b, Bd(d[e]);
                delete a.g[c];
                a.h--
            }
        }
        this.P = null
    };
    var Ld = function(a, b, c, d, e) {
            Je(a);
            return a.i.add(String(b), c, !1, d, e)
        },
        Ke = function(a, b, c, d) {
            b = a.i.g[String(b)];
            if (!b) return !0;
            b = b.concat();
            for (var e = !0, g = 0; g < b.length; ++g) {
                var f = b[g];
                if (f && !f.G && f.capture == c) {
                    var h = f.listener,
                        k = f.M || f.src;
                    f.K && Ed(a.i, f);
                    e = !1 !== h.call(k, d) && e
                }
            }
            return e && !d.defaultPrevented
        },
        Je = function(a) {
            y(a.i, "Event target is not initialized. Did you call the superclass (goog.events.EventTarget) constructor?")
        };
    var Le = function(a, b) {
        this.name = a;
        this.value = b
    };
    Le.prototype.toString = function() {
        return this.name
    };
    var Me = new Le("OFF", Infinity),
        Ne = new Le("SEVERE", 1E3),
        Oe = new Le("CONFIG", 700),
        Pe = new Le("FINE", 500),
        Qe = function() {},
        Re, Se = function(a, b, c) {
            this.reset(a || Me, b, c, void 0, void 0)
        };
    Se.prototype.reset = function() {};
    var Te = function(a, b) {
            this.g = null;
            this.j = [];
            this.h = (void 0 === b ? null : b) || null;
            this.i = [];
            this.l = {
                g: function() {
                    return a
                }
            }
        },
        Ue = function(a) {
            if (a.g) return a.g;
            if (a.h) return Ue(a.h);
            Qa("Root logger has no level set.");
            return Me
        },
        Ve = function(a, b) {
            for (; a;) a.j.forEach(function(c) {
                c(b)
            }), a = a.h
        },
        We = function() {
            this.entries = {};
            var a = new Te("");
            a.g = Oe;
            this.entries[""] = a
        },
        Xe, Ye = function(a, b, c) {
            var d = a.entries[b];
            if (d) return void 0 !== c && (d.g = c), d;
            d = Ye(a, b.substr(0, b.lastIndexOf(".")));
            var e = new Te(b, d);
            a.entries[b] =
                e;
            d.i.push(e);
            void 0 !== c && (e.g = c);
            return e
        },
        Ze = function() {
            Xe || (Xe = new We);
            return Xe
        },
        $e = function(a, b, c) {
            var d;
            if (d = a)
                if (d = a && b) {
                    d = b.value;
                    var e = a ? Ue(Ye(Ze(), a.g())) : Me;
                    d = d >= e.value
                }
            d && (b = b || Me, d = Ye(Ze(), a.g()), "function" === typeof c && (c = c()), Re || (Re = new Qe), a = new Se(b, c, a.g()), Ve(d, a))
        },
        K = function(a, b) {
            a && $e(a, Pe, b)
        };
    var af = function() {};
    af.prototype.g = null;
    var cf = function(a) {
        var b;
        (b = a.g) || (b = {}, bf(a) && (b[0] = !0, b[1] = !0), b = a.g = b);
        return b
    };
    var df, ef = function() {};
    x(ef, af);
    var ff = function(a) {
            return (a = bf(a)) ? new ActiveXObject(a) : new XMLHttpRequest
        },
        bf = function(a) {
            if (!a.h && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
                for (var b = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], c = 0; c < b.length; c++) {
                    var d = b[c];
                    try {
                        return new ActiveXObject(d), a.h = d
                    } catch (e) {}
                }
                throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
            }
            return a.h
        };
    df = new ef;
    var M = function(a, b) {
        this.h = {};
        this.g = [];
        this.i = 0;
        var c = arguments.length;
        if (1 < c) {
            if (c % 2) throw Error("Uneven number of arguments");
            for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
        } else if (a)
            if (a instanceof M)
                for (c = a.F(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
            else
                for (d in a) this.set(d, a[d])
    };
    M.prototype.j = function() {
        gf(this);
        for (var a = [], b = 0; b < this.g.length; b++) a.push(this.h[this.g[b]]);
        return a
    };
    M.prototype.F = function() {
        gf(this);
        return this.g.concat()
    };
    var gf = function(a) {
        if (a.i != a.g.length) {
            for (var b = 0, c = 0; b < a.g.length;) {
                var d = a.g[b];
                P(a.h, d) && (a.g[c++] = d);
                b++
            }
            a.g.length = c
        }
        if (a.i != a.g.length) {
            var e = {};
            for (c = b = 0; b < a.g.length;) d = a.g[b], P(e, d) || (a.g[c++] = d, e[d] = 1), b++;
            a.g.length = c
        }
    };
    M.prototype.get = function(a, b) {
        return P(this.h, a) ? this.h[a] : b
    };
    M.prototype.set = function(a, b) {
        P(this.h, a) || (this.i++, this.g.push(a));
        this.h[a] = b
    };
    M.prototype.forEach = function(a, b) {
        for (var c = this.F(), d = 0; d < c.length; d++) {
            var e = c[d],
                g = this.get(e);
            a.call(b, g, e, this)
        }
    };
    var P = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    var hf = function(a, b, c) {
        if ("function" === typeof a) c && (a = w(a, c));
        else if (a && "function" == typeof a.handleEvent) a = w(a.handleEvent, a);
        else throw Error("Invalid listener argument");
        return 2147483647 < Number(b) ? -1 : u.setTimeout(a, b || 0)
    };
    var Q = function(a) {
        I.call(this);
        this.headers = new M;
        this.J = a || null;
        this.j = !1;
        this.D = this.g = null;
        this.u = this.V = this.v = "";
        this.l = this.O = this.H = this.N = !1;
        this.m = 0;
        this.B = null;
        this.X = "";
        this.C = this.R = !1
    };
    x(Q, I);
    Q.prototype.h = Ye(Ze(), "goog.net.XhrIo", void 0).l;
    var jf = /^https?$/i,
        kf = ["POST", "PUT"],
        lf = [],
        nf = function(a, b) {
            var c = new Q;
            lf.push(c);
            b && Ld(c, "complete", b);
            c.i.add("ready", c.ba, !0, void 0, void 0);
            c.m = 5E3;
            c.R = !0;
            mf(c, a);
            return c
        };
    Q.prototype.ba = function() {
        this.s || (this.s = !0, this.o());
        ib(lf, this)
    };
    var mf = function(a, b) {
            if (a.g) throw Error("[goog.net.XhrIo] Object is active with another request=" + a.v + "; newUri=" + b);
            a.v = b;
            a.u = "";
            a.V = "GET";
            a.N = !1;
            a.j = !0;
            a.g = a.J ? ff(a.J) : ff(df);
            a.D = a.J ? cf(a.J) : cf(df);
            a.g.onreadystatechange = w(a.W, a);
            try {
                K(a.h, R(a, "Opening Xhr")), a.O = !0, a.g.open("GET", String(b), !0), a.O = !1
            } catch (e) {
                K(a.h, R(a, "Error opening Xhr: " + e.message)); of (a, e);
                return
            }
            b = new M(a.headers);
            var c = gb(b.F()),
                d = u.FormData && !1;
            !(0 <= Sa(kf, "GET")) || c || d || b.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
            b.forEach(function(e, g) {
                this.g.setRequestHeader(g, e)
            }, a);
            a.X && (a.g.responseType = a.X);
            "withCredentials" in a.g && a.g.withCredentials !== a.R && (a.g.withCredentials = a.R);
            try {
                pf(a), 0 < a.m && (a.C = qf(a.g), K(a.h, R(a, "Will abort after " + a.m + "ms if incomplete, xhr2 " + a.C)), a.C ? (a.g.timeout = a.m, a.g.ontimeout = w(a.Y, a)) : a.B = hf(a.Y, a.m, a)), K(a.h, R(a, "Sending request")), a.H = !0, a.g.send(""), a.H = !1
            } catch (e) {
                K(a.h, R(a, "Send error: " + e.message)), of (a, e)
            }
        },
        qf = function(a) {
            return Jb && Tb(9) && "number" === typeof a.timeout && void 0 !==
                a.ontimeout
        },
        hb = function(a) {
            return "content-type" == a.toLowerCase()
        };
    Q.prototype.Y = function() {
        "undefined" != typeof Ea && this.g && (this.u = "Timed out after " + this.m + "ms, aborting", K(this.h, R(this, this.u)), J(this, "timeout"), this.abort(8))
    };
    var of = function(a, b) {
        a.j = !1;
        a.g && (a.l = !0, a.g.abort(), a.l = !1);
        a.u = b;
        rf(a);
        sf(a)
    }, rf = function(a) {
        a.N || (a.N = !0, J(a, "complete"), J(a, "error"))
    };
    Q.prototype.abort = function() {
        this.g && this.j && (K(this.h, R(this, "Aborting")), this.j = !1, this.l = !0, this.g.abort(), this.l = !1, J(this, "complete"), J(this, "abort"), sf(this))
    };
    Q.prototype.o = function() {
        this.g && (this.j && (this.j = !1, this.l = !0, this.g.abort(), this.l = !1), sf(this, !0));
        Q.I.o.call(this)
    };
    Q.prototype.W = function() {
        this.s || (this.O || this.H || this.l ? tf(this) : this.ca())
    };
    Q.prototype.ca = function() {
        tf(this)
    };
    var tf = function(a) {
            if (a.j && "undefined" != typeof Ea)
                if (a.D[1] && 4 == uf(a) && 2 == vf(a)) K(a.h, R(a, "Local request error detected and ignored"));
                else if (a.H && 4 == uf(a)) hf(a.W, 0, a);
            else if (J(a, "readystatechange"), 4 == uf(a)) {
                K(a.h, R(a, "Request complete"));
                a.j = !1;
                try {
                    if (wf(a)) J(a, "complete"), J(a, "success");
                    else {
                        try {
                            var b = 2 < uf(a) ? a.g.statusText : ""
                        } catch (c) {
                            K(a.h, "Can not get status: " + c.message), b = ""
                        }
                        a.u = b + " [" + vf(a) + "]";
                        rf(a)
                    }
                } finally {
                    sf(a)
                }
            }
        },
        sf = function(a, b) {
            if (a.g) {
                pf(a);
                var c = a.g,
                    d = a.D[0] ? Fa : null;
                a.g = null;
                a.D =
                    null;
                b || J(a, "ready");
                try {
                    c.onreadystatechange = d
                } catch (e) {
                    (a = a.h) && $e(a, Ne, "Problem encountered resetting onreadystatechange: " + e.message)
                }
            }
        },
        pf = function(a) {
            a.g && a.C && (a.g.ontimeout = null);
            a.B && (u.clearTimeout(a.B), a.B = null)
        },
        wf = function(a) {
            var b = vf(a);
            a: switch (b) {
                case 200:
                case 201:
                case 202:
                case 204:
                case 206:
                case 304:
                case 1223:
                    var c = !0;
                    break a;
                default:
                    c = !1
            }
            if (!c) {
                if (b = 0 === b) a = String(a.v).match($b)[1] || null, !a && u.self && u.self.location && (a = u.self.location.protocol, a = a.substr(0, a.length - 1)), b = !jf.test(a ?
                    a.toLowerCase() : "");
                c = b
            }
            return c
        },
        uf = function(a) {
            return a.g ? a.g.readyState : 0
        },
        vf = function(a) {
            try {
                return 2 < uf(a) ? a.g.status : -1
            } catch (b) {
                return -1
            }
        },
        R = function(a, b) {
            return b + " [" + a.V + " " + a.v + " " + vf(a) + "]"
        };
    var S = function(a, b) {
        this.h = this.o = this.j = "";
        this.s = null;
        this.m = this.g = "";
        this.l = !1;
        var c;
        a instanceof S ? (this.l = void 0 !== b ? b : a.l, xf(this, a.j), this.o = a.o, this.h = a.h, yf(this, a.s), this.g = a.g, zf(this, Af(a.i)), this.m = a.m) : a && (c = String(a).match($b)) ? (this.l = !!b, xf(this, c[1] || "", !0), this.o = Bf(c[2] || ""), this.h = Bf(c[3] || "", !0), yf(this, c[4]), this.g = Bf(c[5] || "", !0), zf(this, c[6] || "", !0), this.m = Bf(c[7] || "")) : (this.l = !!b, this.i = new T(null, this.l))
    };
    S.prototype.toString = function() {
        var a = [],
            b = this.j;
        b && a.push(Cf(b, Df, !0), ":");
        var c = this.h;
        if (c || "file" == b) a.push("//"), (b = this.o) && a.push(Cf(b, Df, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.s, null != c && a.push(":", String(c));
        if (c = this.g) this.h && "/" != c.charAt(0) && a.push("/"), a.push(Cf(c, "/" == c.charAt(0) ? Ef : Ff, !0));
        (c = this.i.toString()) && a.push("?", c);
        (c = this.m) && a.push("#", Cf(c, Gf));
        return a.join("")
    };
    S.prototype.resolve = function(a) {
        var b = new S(this),
            c = !!a.j;
        c ? xf(b, a.j) : c = !!a.o;
        c ? b.o = a.o : c = !!a.h;
        c ? b.h = a.h : c = null != a.s;
        var d = a.g;
        if (c) yf(b, a.s);
        else if (c = !!a.g) {
            if ("/" != d.charAt(0))
                if (this.h && !this.g) d = "/" + d;
                else {
                    var e = b.g.lastIndexOf("/"); - 1 != e && (d = b.g.substr(0, e + 1) + d)
                }
            e = d;
            if (".." == e || "." == e) d = "";
            else if (C(e, "./") || C(e, "/.")) {
                d = 0 == e.lastIndexOf("/", 0);
                e = e.split("/");
                for (var g = [], f = 0; f < e.length;) {
                    var h = e[f++];
                    "." == h ? d && f == e.length && g.push("") : ".." == h ? ((1 < g.length || 1 == g.length && "" != g[0]) && g.pop(), d &&
                        f == e.length && g.push("")) : (g.push(h), d = !0)
                }
                d = g.join("/")
            } else d = e
        }
        c ? b.g = d : c = "" !== a.i.toString();
        c ? zf(b, Af(a.i)) : c = !!a.m;
        c && (b.m = a.m);
        return b
    };
    var xf = function(a, b, c) {
            a.j = c ? Bf(b, !0) : b;
            a.j && (a.j = a.j.replace(/:$/, ""))
        },
        yf = function(a, b) {
            if (b) {
                b = Number(b);
                if (isNaN(b) || 0 > b) throw Error("Bad port number " + b);
                a.s = b
            } else a.s = null
        },
        zf = function(a, b, c) {
            b instanceof T ? (a.i = b, Hf(a.i, a.l)) : (c || (b = Cf(b, If)), a.i = new T(b, a.l))
        },
        Bf = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        Cf = function(a, b, c) {
            return "string" === typeof a ? (a = encodeURI(a).replace(b, Jf), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        Jf = function(a) {
            a =
                a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        Df = /[#\/\?@]/g,
        Ff = /[#\?:]/g,
        Ef = /[#\?]/g,
        If = /[#\?@]/g,
        Gf = /#/g,
        T = function(a, b) {
            this.h = this.g = null;
            this.i = a || null;
            this.l = !!b
        },
        X = function(a) {
            a.g || (a.g = new M, a.h = 0, a.i && ac(a.i, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
            }))
        };
    T.prototype.add = function(a, b) {
        X(this);
        this.i = null;
        a = Kf(this, a);
        var c = this.g.get(a);
        c || this.g.set(a, c = []);
        c.push(b);
        this.h = Ra(this.h) + 1;
        return this
    };
    var Lf = function(a, b) {
            X(a);
            b = Kf(a, b);
            P(a.g.h, b) && (a.i = null, a.h = Ra(a.h) - a.g.get(b).length, a = a.g, P(a.h, b) && (delete a.h[b], a.i--, a.g.length > 2 * a.i && gf(a)))
        },
        Mf = function(a, b) {
            X(a);
            b = Kf(a, b);
            return P(a.g.h, b)
        };
    T.prototype.forEach = function(a, b) {
        X(this);
        this.g.forEach(function(c, d) {
            Ta(c, function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    T.prototype.F = function() {
        X(this);
        for (var a = this.g.j(), b = this.g.F(), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], g = 0; g < e.length; g++) c.push(b[d]);
        return c
    };
    T.prototype.j = function(a) {
        X(this);
        var b = [];
        if ("string" === typeof a) Mf(this, a) && (b = jb(b, this.g.get(Kf(this, a))));
        else {
            a = this.g.j();
            for (var c = 0; c < a.length; c++) b = jb(b, a[c])
        }
        return b
    };
    T.prototype.set = function(a, b) {
        X(this);
        this.i = null;
        a = Kf(this, a);
        Mf(this, a) && (this.h = Ra(this.h) - this.g.get(a).length);
        this.g.set(a, [b]);
        this.h = Ra(this.h) + 1;
        return this
    };
    T.prototype.get = function(a, b) {
        if (!a) return b;
        a = this.j(a);
        return 0 < a.length ? String(a[0]) : b
    };
    T.prototype.toString = function() {
        if (this.i) return this.i;
        if (!this.g) return "";
        for (var a = [], b = this.g.F(), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.j(d);
            for (var g = 0; g < d.length; g++) {
                var f = e;
                "" !== d[g] && (f += "=" + encodeURIComponent(String(d[g])));
                a.push(f)
            }
        }
        return this.i = a.join("&")
    };
    var Af = function(a) {
            var b = new T;
            b.i = a.i;
            a.g && (b.g = new M(a.g), b.h = a.h);
            return b
        },
        Kf = function(a, b) {
            b = String(b);
            a.l && (b = b.toLowerCase());
            return b
        },
        Hf = function(a, b) {
            b && !a.l && (X(a), a.i = null, a.g.forEach(function(c, d) {
                var e = d.toLowerCase();
                if (d != e && (Lf(this, d), Lf(this, e), 0 < c.length)) {
                    this.i = null;
                    d = this.g;
                    var g = d.set;
                    e = Kf(this, e);
                    var f = c.length;
                    if (0 < f) {
                        for (var h = Array(f), k = 0; k < f; k++) h[k] = c[k];
                        f = h
                    } else f = [];
                    g.call(d, e, f);
                    this.h = Ra(this.h) + c.length
                }
            }, a));
            a.l = b
        };
    var Nf = [2],
        Of = void 0,
        Pf = new function() {};
    Pf.refreshPeriod = 3E5;
    Pf.refreshDuration = 108E5;
    var Qf = function() {
            this.autoRefresh = !0
        },
        Rf = function() {},
        Sf = function() {},
        Tf = function() {},
        Uf = function() {},
        Vf = function(a) {
            this.g = a
        },
        Wf = function(a, b) {
            this.g = a;
            this.h = b
        },
        Xf = function(a) {
            var b = a.g.adData;
            return null == b ? (Y("adData is null"), !1) : null == b.cl || null == b.ak ? (Y("missing conversion label or advertiser key"), !1) : null == a.g.destinationNumber ? (Y("no replace number"), !1) : !0
        },
        Yf = function() {},
        $f = function(a, b, c) {
            var d = this;
            this.g = b;
            this.l = b.destinationNumber;
            this.j = c || new Qf;
            this.i = !1;
            "function" === typeof a ?
                (this.i = !0, this.j.autoRefresh = !0) : null == a && (a = function(e, g) {
                    Zf(d.l, e, g)
                });
            this.m = a;
            this.h = Pf
        },
        jg = function(a) {
            var b, c, d, e, g, f, h;
            return t(function(k) {
                if (1 == k.g) {
                    if (!ag(a)) return k.return();
                    b = bg(a);
                    if (null == b) return k.return();
                    c = cg(b);
                    d = dg(c);
                    e = null === d ? eg(b) : d;
                    g = a;
                    return r(k, fg(e).catch(function(l) {
                        Y(l);
                        return Pf
                    }), 2)
                }
                g.h = k.m;
                f = a.h;
                gg(c, e, Date.now() + f.refreshDuration);
                f.phoneNumber && f.formattedPhoneNumber && (h = hg(f.phoneNumber, a.g.destinationNumber, f.formattedPhoneNumber), ig(a, h, f.phoneNumber));
                k.g =
                    0
            })
        },
        lg = function(a) {
            var b, c, d;
            return t(function(e) {
                if (1 == e.g) return r(e, jg(a), 2);
                if (!a.j.autoRefresh) return e.return();
                b = a.h.refreshPeriod || 3E5;
                c = setInterval(function() {
                    if (!document.hidden || a.i) return jg(a)
                }, b);
                d = Jd(document, "visibilitychange", a.o.bind(a));
                setTimeout(function() {
                    clearInterval(c);
                    Sd(d);
                    setTimeout(function() {
                        kg(a)
                    }, 2 * b)
                }, a.h.refreshDuration || 108E5);
                e.g = 0
            })
        };
    $f.prototype.o = function() {
        var a = this;
        return t(function(b) {
            if (document.hidden && !a.i) return b.return();
            kg(a);
            return b.return(jg(a))
        })
    };
    var ag = function(a) {
            return null == a.g.destinationNumber ? (Y("no destination number"), !1) : null == a.g.countryNameCode ? (Y("no country name code"), !1) : "function" !== typeof a.m && "string" !== typeof a.m ? (Y("Invalid receiver."), !1) : !0
        },
        bg = function(a) {
            var b = new Yf;
            if (null == a.g.adData) var c = null;
            else {
                var d = new Wf(a.g, a.j);
                if (Xf(d)) {
                    var e = new Rf,
                        g = d.g.adData;
                    e.ak = g.ak;
                    e.cl = g.cl;
                    e.alloc = d.h && d.h.alloc;
                    var f = window,
                        h = document,
                        k = f.location.href;
                    var l = (k instanceof S ? new S(k) : new S(k, void 0)).i.get("gclid");
                    e.T = l || "";
                    e.na = h.referrer;
                    for (var q = {}, O = 0; O < qd.length; O++) {
                        var v = qd[O];
                        q[v] = f[v]
                    }
                    q.onload_callback = f.onload_callback;
                    var B = q.google_gcl_cookie_prefix;
                    b: {
                        if (nd.test(h.location.host)) {
                            var H = h.location.href.match(pd);
                            if (H && 2 == H.length && H[1].match(md)) {
                                var N = H[1];
                                break b
                            }
                        } else {
                            var U = [];
                            if (h.cookie) {
                                var Ua, wg = h.cookie;
                                if (id()) {
                                    for (var Yd = [], Zd = String(wg || document.cookie).split(";"), fc = 0; fc < Zd.length; fc++) {
                                        var $d = Zd[fc].split("="),
                                            ae = $d[0].replace(/^\s*|\s*$/g, "");
                                        if (ae && ae == (B || "_gcl") + "_aw") {
                                            var xg = $d.slice(1).join("=").replace(/^\s*|\s*$/g,
                                                "");
                                            Yd.push(xg)
                                        }
                                    }
                                    var be = Yd
                                } else be = [];
                                if ((Ua = be) && 0 != Ua.length) {
                                    for (var gc = 0; gc < Ua.length; gc++) {
                                        var Va = Ua[gc].split(".");
                                        var yg = 3 == Va.length && "GCL" == Va[0] && Va[1] ? Va[2] : void 0;
                                        var Wa = yg,
                                            hc;
                                        if (hc = Wa) {
                                            d: if (Array.prototype.indexOf) {
                                                var ce = U.indexOf(Wa);
                                                var ic = "number" == typeof ce ? ce : -1
                                            } else {
                                                for (var Xa = 0; Xa < U.length; Xa++)
                                                    if (U[Xa] === Wa) {
                                                        ic = Xa;
                                                        break d
                                                    }
                                                ic = -1
                                            }hc = -1 === ic
                                        }
                                        hc && U.push(Wa)
                                    }
                                    var jc = kd(U)
                                } else jc = U
                            } else jc = U;
                            var de = jc;
                            if (0 < de.length) {
                                N = de.join(".");
                                break b
                            }
                        }
                        N = ""
                    }
                    e.ma = N;
                    if (nd.test(h.location.host)) {
                        var Ya =
                            h.location.href.match(od);
                        var ee = Ya && 2 == Ya.length && Ya[1].match(ld) ? decodeURIComponent(Ya[1]) : ""
                    } else {
                        if ($c() && $c() && bd().active) {
                            var fe = hd("ad_storage");
                            var ge = null == fe ? !0 : !!fe
                        } else ge = !0;
                        if (ge) {
                            for (var L = [], he = h.cookie.split(";"), zg = /^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/, kc = 0; kc < he.length; kc++) {
                                var lc = he[kc].match(zg);
                                lc && L.push({
                                    U: lc[1],
                                    value: lc[2]
                                })
                            }
                            var Za = {};
                            if (L && L.length)
                                for (var ha = 0; ha < L.length; ha++) {
                                    var wa = L[ha].value.split(".");
                                    "1" == wa[0] && 3 == wa.length && wa[1] && (Za[L[ha].U] || (Za[L[ha].U] = []),
                                        Za[L[ha].U].push({
                                            timestamp: wa[1],
                                            T: wa[2]
                                        }))
                                }
                            var ie = Za
                        } else ie = {};
                        var je = ie;
                        var mc = [],
                            nc;
                        for (nc in je) {
                            for (var ke = [], le = je[nc], oc = 0; oc < le.length; oc++) ke.push(le[oc].T);
                            mc.push(nc + ":" + ke.join(","))
                        }
                        ee = 0 < mc.length ? mc.join(";") : ""
                    }
                    e.ga = ee;
                    c = e
                } else c = null
            }
            b.g = c;
            if (null == a.g.gaData) var pc = null;
            else {
                var me = new Vf(a.g);
                var qc = me.g.gaData;
                if (null == qc) {
                    Y("gaData is null");
                    var rc = !1
                } else if (null == qc.gaWpid) Y("missing gaWpid"), rc = !1;
                else {
                    c: {
                        var Ag = qc.gaWpid,
                            sc = window._gaUserPrefs;
                        if (sc && sc.ioo && sc.ioo() || document.getElementById("__gaOptOutExtension") ||
                            !0 === window["ga-disable-" + Ag]) var tc = !0;
                        else {
                            try {
                                var ne = window.external;
                                if (ne && "oo" == ne._gaUserPrefs) {
                                    tc = !0;
                                    break c
                                }
                            } catch (oe) {}
                            tc = !1
                        }
                    }
                    rc = tc ? !1 : !0
                }
                if (rc) {
                    var V = new Uf;
                    V.gaWpid = me.g.gaData.gaWpid;
                    var pe = 0;
                    try {
                        pe = window.history.length
                    } catch (oe) {}
                    var Bg = pe,
                        qe = document.domain,
                        xa = document.cookie,
                        $a = window.screen,
                        Cg = document.referrer,
                        Dg = window;
                    if (dc()) var re = Qc().gaGlobal || {};
                    else {
                        var uc = Math.round((new Date).getTime() / 1E3),
                            vc = Dg.google_analytics_domain_name,
                            ab = "undefined" == typeof vc ? Tc("auto", qe) : Tc(vc,
                                qe),
                            Eg = -1 < xa.indexOf("__utma=" + ab + "."),
                            Fg = -1 < xa.indexOf("__utmb=" + ab),
                            wc;
                        if (!(wc = Rc().gaGlobal)) {
                            var Gg = {};
                            wc = Rc().gaGlobal = Gg
                        }
                        var p = wc,
                            se = !1;
                        if (Eg) {
                            var xc = xa.split("__utma=" + ab + ".")[1].split(";")[0].split(".");
                            Fg ? p.sid = xc[3] + "" : p.sid || (p.sid = uc + "");
                            p.vid = xc[0] + "." + xc[1];
                            p.from_cookie = !0
                        } else {
                            p.sid || (p.sid = uc + "");
                            if (!p.vid) {
                                se = !0;
                                var Hg = Math.round(2147483647 * Math.random()),
                                    te = Bg,
                                    ue, Ig = F.appName,
                                    Jg = F.version,
                                    Kg = F.language ? F.language : F.browserLanguage,
                                    Lg = F.platform,
                                    Mg = F.userAgent;
                                try {
                                    var ve = F.javaEnabled()
                                } catch (oe) {
                                    ve = !1
                                }
                                var W = [Ig, Jg, Kg, Lg, Mg, ve ? 1 : 0].join("");
                                if ($a) W += $a.width + "x" + $a.height + $a.colorDepth;
                                else if (u.java && u.java.awt) {
                                    var we = u.java.awt.Toolkit.getDefaultToolkit().getScreenSize();
                                    W += we.screen.width + "x" + we.screen.height
                                }
                                W = W + xa + (Cg || "");
                                for (ue = W.length; 0 < te;) W += te-- ^ ue++;
                                p.vid = (Hg ^ Sc(W) & 2147483647) + "." + uc
                            }
                            p.from_cookie = !1
                        }
                        if (!p.cid) {
                            c: {
                                var ia = vc,
                                    xe = 999;ia && (ia = 0 == ia.indexOf(".") ? ia.substr(1) : ia, xe = ("" + ia).split(".").length);
                                for (var ye, ze = 999, bb = xa.split(";"), ya = 0; ya < bb.length; ya++) {
                                    var cb = Uc.exec(bb[ya]) ||
                                        Vc.exec(bb[ya]) || Wc.exec(bb[ya]);
                                    if (cb) {
                                        var yc = cb[1] || 0;
                                        if (yc == xe) {
                                            var Ae = cb[2];
                                            break c
                                        }
                                        yc < ze && (ze = yc, ye = cb[2])
                                    }
                                }
                                Ae = ye
                            }
                            var za = Ae;se && za && -1 != za.search(/^\d+\.\d+$/) ? (p.vid = za, p.from_cookie = !0) : za != p.vid && (p.cid = za)
                        }
                        p.dh = ab;
                        p.hid || (p.hid = Math.round(2147483647 * Math.random()));
                        re = p
                    }
                    var zc = re;
                    V.fa = zc.cid;
                    V.ka = zc.vid;
                    V.ha = zc.hid;
                    var Aa = document.location;
                    if (Aa) {
                        var db = Aa.pathname || "";
                        "/" != db.charAt(0) && (db = "/" + db);
                        var Be = Aa.protocol + "//" + Aa.hostname + db + Aa.search
                    } else Be = void 0;
                    V.ia = Be;
                    var Ce = document,
                        eb =
                        Ce.referrer,
                        Ac;
                    if (Ac = /^(https?|android-app):\/\//i.test(eb)) {
                        c: {
                            var De = "//" + Ce.location.hostname,
                                Bc = eb.indexOf(De);
                            if (5 == Bc || 6 == Bc) {
                                var fb = eb.charAt(Bc + De.length);
                                if ("/" == fb || "?" == fb || "" == fb || ":" == fb) {
                                    var Ee = !0;
                                    break c
                                }
                            }
                            Ee = !1
                        }
                        Ac = !Ee
                    }
                    var Ng = Ac ? eb : void 0;
                    V.ja = Ng;
                    pc = V
                } else pc = null
            }
            b.h = pc;
            if (null == b.g && null == b.h) return Y("missing call tracking data"), null;
            b.experimentIDs = (a.j || {}).experimentIDs || Nf;
            b.i = a.g.destinationNumber.replace(/[^0-9A-Z]/gi, "");
            b.countryNameCode = a.g.countryNameCode;
            return b
        },
        ig =
        function(a, b, c) {
            var d = a.m;
            if ("function" === typeof d) mg() || (Y("Sending ", b, " to callback"), Z("success")), d(b, c);
            else if (d) {
                var e = [],
                    g = document.getElementById(d);
                g && e.push(g);
                (g = document) ? (y(g, "Node cannot be null or undefined."), g = new Zb(9 == g.nodeType ? g : g.ownerDocument || g.document)) : g = Na || (Na = new Zb);
                var f = (g = g.g) || document;
                g = f.querySelectorAll && f.querySelector ? f.querySelectorAll("." + d) : Yb(d, g);
                for (f = 0; f !== g.length; ++f) e.push(g[f]);
                if (0 === e.length) Y("Found no elements matching ", d), Z("receiver not found");
                else {
                    for (d = 0; d !== e.length; d++) {
                        for (f = e[d]; g = f.firstChild;) f.removeChild(g);
                        e[d].appendChild(document.createTextNode(b));
                        g = ng(e[d], c);
                        null !== g && void 0 === Of && (Of = g)
                    }
                    Y("Updated ", e.length, " element(s) with ", b);
                    Z("success")
                }
            }
            a.l = b
        },
        kg = function(a) {
            !a.i && Of && ig(a, a.g.destinationNumber, Of)
        },
        og = null,
        pg = !1;

    function qg() {
        var a = document.getElementById("google-wcc-debug-window");
        if (a) return a;
        var b = function(d) {
                if ("string" === typeof d) return document.createTextNode(d);
                var e = document.createElement(d[0]);
                e.setAttribute("style", d[1] + ";");
                if (d[2])
                    for (var g = 0; g !== d[2].length; ++g) e.appendChild(b(d[2][g]));
                return e
            },
            c = b(["div", "background-color:#fafafa;color:#000;border:1px solid #ddd;border-radius:3px;font-family:sans-serif;font-size:13px;position:fixed;bottom:0;left:0;width:40em;display:block;text-align:left;z-index:2147483645", [
                ["div", "color:#222;font-size:16px;border-bottom:1px solid #ddd;padding:13px", ["Google AdWords Website Call Conversions", ["span", "float:right", [
                    ["button", "border:1px solid #ddd;background-color:#fff;font-weight:bold;font-size:12px;padding:4px 8px;color:#444;box-shadow:#eee 0px 1px 0px 0px", ["Force"]],
                    ["button", "border:1px solid #ddd;background-color:#fff;font-weight:bold;font-size:12px;padding:4px 8px;color:#444;box-shadow:#eee 0px 1px 0px 0px", ["Close"]]
                ]]]],
                ["div", "height:10em;padding:10px;overflow-y:auto"]
            ]]);
        document.body.appendChild(c);
        a = c.childNodes[0].childNodes[1].childNodes;
        a[0].onclick = function() {
            return t(function(d) {
                if (og) {
                    var e = og;
                    var g = e.l.replace(/\d/g, "9");
                    g = ["+" + g.replace(/[^0-9]/g, ""), g];
                    var f = ea(g);
                    g = f.next().value;
                    f = f.next().value;
                    ig(e, f, g)
                }
                d.g = 0
            })
        };
        a[1].onclick = function() {
            c.style.display = "none"
        };
        a = c.childNodes[1];
        a.id = "google-wcc-debug-window";
        return a
    }

    function Y(a) {
        if (pg) {
            for (var b = "", c = 0; c !== arguments.length; ++c) {
                if ("string" !== typeof arguments[c]) {
                    var d = arguments,
                        e = c,
                        g = [];
                    Fe(new Xd, arguments[c], g);
                    d[e] = g.join("")
                }
                b += arguments[c]
            }
            "" !== b && ("." !== b[b.length - 1] && (b += "."), c = qg(), c.appendChild(document.createTextNode(b)), c.appendChild(document.createElement("br")))
        }
    }

    function cg(a) {
        var b = [];
        a.g && b.push(a.g.cl);
        a.h && b.push(a.h.gaWpid);
        b.push(a.i);
        return b.join(",")
    }

    function dg(a) {
        var b = window.localStorage.getItem(a + "_expiresAt");
        return null == b || Number(b) < Date.now() ? null : window.localStorage.getItem(a)
    }

    function gg(a, b, c) {
        var d = window.localStorage,
            e = d.getItem(a + "_expiresAt");
        if (null == e || Number(e) < Date.now()) d.setItem(a + "_expiresAt", c.toString()), d.setItem(a, b)
    }

    function eg(a) {
        var b = a.h || {},
            c = a.g || {},
            d = {
                cc: a.countryNameCode,
                dn: a.i,
                ga_wpid: b.gaWpid,
                ga_vid: b.ka,
                ga_hid: b.ha,
                ga_cid: b.fa,
                ga_loc: b.ia,
                ga_ref: b.ja,
                cl: c.cl,
                alloc: c.alloc,
                gclid: c.T,
                ref: c.na,
                gac: c.ga,
                gclaw: c.ma,
                ct_eid: (a.experimentIDs || []).join()
            };
        Object.keys(d).forEach(function(e) {
            return !d[e] && delete d[e]
        });
        return a.g ? xb(new z(nb, "https://www.googleadservices.com/pagead/conversion/%{ak}/wcm"), {
            ak: c.ak
        }, d).g() : xb(new z(nb, "https://www.googleadservices.com/ga/phone"), {}, d).g()
    }

    function rg(a) {
        switch (a) {
            case 2:
                return "no ad click";
            case 4:
                return "not tracked";
            case 8:
                return "temporary error"
        }
        return "error #" + a
    }

    function fg(a) {
        return new Promise(function(b, c) {
            Ld(nf(a, function(d) {
                if (wf(d.target) && 200 == vf(d.target)) {
                    d = d.target;
                    if (d.g) b: {
                        d = d.g.responseText;
                        if (u.JSON) try {
                            var e = u.JSON.parse(d);
                            y("object" == typeof e);
                            var g = e;
                            break b
                        } catch (f) {}
                        g = Wd(d)
                    }
                    else g = void 0;
                    g.errorCode && Z(rg(g.errorCode));
                    b(g)
                } else c("request phone number failure")
            }), "timeout", function() {
                c("request timeout")
            })
        })
    }

    function sg(a) {
        if (a = !window.google_no_debug && (!a || !a.noDebug)) a = window.location.hash, a = a.startsWith("#google-wcc-") || a.startsWith("#google-phone-") || "undefined" !== typeof window.sessionStorage && "y" === window.sessionStorage.getItem("_goog_wcc_debug");
        pg = a
    }

    function mg() {
        var a = window.google_replace_number;
        return "string" === typeof a && 0 < a.length
    }

    function Z(a) {
        window.google_wcc_status = a
    }

    function hg(a, b, c) {
        if (a.match(/^\+1\d{10}$/)) {
            var d = b.match(/\d/g);
            d = d ? d.length : 0;
            if (10 !== d && 11 !== d) b = null;
            else {
                d = 11 === d ? 1 : 2;
                for (var e = "", g = 0; g !== b.length; ++g) e = b.charAt(g).match(/\d/) ? e + a.charAt(d++) : e + b.charAt(g);
                b = e
            }
        } else b = null;
        return b ? b : c ? c : a
    }

    function ng(a, b) {
        a: {
            for (; null != a; a = a.parentNode)
                if ("A" === a.nodeName) {
                    if (a.href && "tel:" === a.href.substr(0, 4)) break a;
                    break
                }
            a = null
        }
        if (null != a) {
            var c = a.href.slice(4);
            b = "tel:" + b;
            var d = String(b.substr(0, 4)).toLowerCase();
            0 == ("tel:" < d ? -1 : "tel:" == d ? 0 : 1) || (b = "about:invalid#zClosurez");
            b = new D(b, Ab);
            a: {
                try {
                    var e = a && a.ownerDocument,
                        g = e && (e.defaultView || e.parentWindow);
                    g = g || u;
                    if (g.Element && g.Location) {
                        var f = g;
                        break a
                    }
                } catch (k) {}
                f = null
            }
            if (f && "undefined" != typeof f.HTMLAnchorElement && (!a || !(a instanceof f.HTMLAnchorElement) &&
                    (a instanceof f.Location || a instanceof f.Element))) {
                if (Ha(a)) try {
                    var h = a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a)
                } catch (k) {
                    h = "<object could not be stringified>"
                } else h = void 0 === a ? "undefined" : null === a ? "null" : typeof a;
                Qa("Argument is not a %s (or a non-Element, non-Location mock); got: %s", "HTMLAnchorElement", h)
            }
            b instanceof D ? f = b : (f = b, f instanceof D || (f = "object" == typeof f && f.h ? f.g() : String(f), y(Bb.test(f), "%s does not match the safe URL pattern", f) || (f = "about:invalid#zClosurez"),
                f = new D(f, Ab)));
            f instanceof D && f.constructor === D ? f = f.i : (Qa("expected object of type SafeUrl, got '" + f + "' of type " + Ga(f)), f = "type_error:SafeUrl");
            a.href = f;
            return c
        }
        return null
    }

    function tg(a, b, c) {
        var d = function(e) {
            if (1 === e.nodeType && ("SCRIPT" === e.nodeName || "google-wcc-debug-window" === e.id)) return 0;
            var g = 0;
            if (3 === e.nodeType && -1 !== e.data.search(a)) {
                e.data = e.data.replace(a, b);
                var f = ng(e, c);
                null !== f && void 0 === Of && (Of = f);
                ++g
            }
            e = e.childNodes;
            for (f = 0; f !== e.length; f++) g += d(e[f]);
            return g
        };
        return d(document.body)
    }

    function Zf(a, b, c) {
        var d = 10,
            e = a.replace(/[^0-9]/g, "");
        if (0 === e.length) Y('The specified number "', a, '" cannot be replaced'), Z("autoreplace fail");
        else {
            var g = new RegExp("\\(?" + e.split("").join("[^0-9]{0,3}"), "g"),
                f = function() {
                    var h = tg(g, b, c);
                    if (0 < h) {
                        if (Y("Updated ", h, " element(s) with ", b), Z("success"), "loading" === document.readyState) {
                            var k = function() {
                                "complete" === document.readyState ? tg(g, b, c) : Id(document, "readystatechange", k)
                            };
                            Id(document, "readystatechange", k)
                        }
                    } else 0 < d-- ? setTimeout(f, 500) : (Y("Could not find ",
                        a, " in the page"), Z("autoreplace fail"))
                };
            f()
        }
    }

    function ug(a, b, c, d, e, g, f) {
        var h;
        return t(function(k) {
            sg(f);
            mg() || c.autoreplace ? Y("Attempting to auto-replace") : "function" === typeof b ? Y("Using callback as target") : "string" === typeof b && Y("Using CSS class '", b, "' as target");
            e && clearTimeout(e);
            h = new Tf;
            h.adData = c;
            h.destinationNumber = d || c.autoreplace;
            h.countryNameCode = "ZZ";
            return r(k, vg(b, h, f), 0)
        })
    }

    function Og(a, b, c) {
        var d = arguments,
            e, g, f;
        return t(function(h) {
            for (e = 3; e < d.length; ++e) g = d[e], null != g && (g.hasOwnProperty("replace") && (c.replace = d[e].replace), g.hasOwnProperty("receiver") && (c.receiver = d[e].receiver), g.hasOwnProperty("destination") && (c.destination = d[e].destination));
            if (null == c.ga_wpid) return h.return();
            f = new Tf;
            f.destinationNumber = c.replace || c.destination;
            f.countryNameCode = "US";
            f.gaData = new Sf;
            f.gaData.gaWpid = c.ga_wpid;
            return r(h, vg(c.receiver, f, null), 0)
        })
    }

    function vg(a, b, c) {
        var d;
        return t(function(e) {
            sg(c);
            og = d = new $f(a, b, c);
            return r(e, lg(d), 0)
        })
    }
    window._googWcmImpl && function() {
        var a, b;
        return t(function(c) {
            if (1 == c.g) {
                a = window._googWcmImpl.q;
                if (!a) {
                    c.g = 0;
                    return
                }
                b = 0
            }
            if (4 != c.g) return b === a.length ? (c.g = 0, c = void 0) : c = r(c, ug.apply(void 0, [].slice.apply(a[b])), 4), c;
            ++b;
            c.g = 3
        })
    }();
    window._googCallTrackingImpl && function() {
        var a, b;
        return t(function(c) {
            if (1 == c.g) {
                a = window._googCallTrackingImpl.q;
                if (!a) {
                    c.g = 0;
                    return
                }
                b = 0
            }
            if (4 != c.g) return b === a.length ? (c.g = 0, c = void 0) : c = r(c, vg.apply(void 0, [].slice.apply(a[b])), 4), c;
            ++b;
            c.g = 3
        })
    }();
    window._gaPhoneImpl && function() {
        var a, b;
        return t(function(c) {
            if (1 == c.g) {
                a = window._gaPhoneImpl.q;
                if (!a) {
                    c.g = 0;
                    return
                }
                b = 0
            }
            if (4 != c.g) return b === a.length ? (c.g = 0, c = void 0) : c = r(c, Og.apply(void 0, [].slice.apply(a[b])), 4), c;
            ++b;
            c.g = 3
        })
    }();
    Ka("_googWcmImpl", ug);
    Ka("_googWccDebug", function(a) {
        if ("undefined" === typeof window.sessionStorage) return "WCC debugging not available.";
        "enable" === a ? window.sessionStorage.setItem("_goog_wcc_debug", "y") : "disable" === a && window.sessionStorage.removeItem("_goog_wcc_debug");
        return "WCC debugging is " + ("y" === window.sessionStorage.getItem("_goog_wcc_debug") ? "enabled." : "disabled.")
    });
    Ka("_googCallTrackingImpl", vg);
    Ka("_gaPhoneImpl", Og);
    if (mg()) {
        var Pg = window.google_replace_number;
        window._googWcmGet(function(a, b) {
            Zf(Pg, a, b)
        }, Pg)
    };
}).call(this);