var h = window.location.href;
var prefix = h.indexOf("www");
var pre = "//";
// if (prefix == -1) {
//     pre = "https://";
// } else {
//     pre = "https://www.";
// }
// var BASE_PATH = pre + window.location.hostname +'/staging/';
// var BASE_PATH = pre + window.location.hostname + '/medisync-website/';
var BASE_PATH = pre + window.location.hostname + '/';