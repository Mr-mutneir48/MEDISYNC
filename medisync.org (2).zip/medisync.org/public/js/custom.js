var patient_id;
var image;
var locationLoading = false;
var preSreachValue;
var load_location_page;
var timeout;
var locationData;
var updating = false;
var cropper;
var preImage;


async function getlocation() {
    $("#form-modal-url").val(window.location.href)
    $.get(BASE_PATH + "getlocation", async function(result, status) {
        result = JSON.parse(result);
        locationData = result;
        if (Number.isInteger(result.pincode)) {
            setCookie("w-u-l", result.pincode) //website user location
        }
        setCookie("w-ip", result.ip) //websiter user ip
        $("#user-header-location").html(result.location)
        $("#user-location-number").val(result.number)
        // $("#call-btn-header-desktop").attr("href","tel:"+result.number)
        // $("#call-btn-header-desktop").html("Speak to a medical expert "+result.number)
        // $("#call-btn-header-mobile").attr("href","tel:"+result.number)
        if ($(".location-specific").length > 0) {
            $(".location-specific").css("display", "block")
            if (result.secondary_pincode != null) {
                $(".location-specific").html("No Doctors found near " + result.location + ". Displaying Doctors near Bangalore location")
                $(".location-specific").css("background-color", "#FF7800")
            } else {
                $(".location-specific").html("Displaying Doctors near " + result.location + " location")
            }
        }

        if ($(".location-specific-hospital").length > 0) {
            if (result.secondary_pincode != null) {
                $(".location-specific-hospital").css("display", "block")
                $(".location-specific-hospital").html("No Hospitals found near " + result.location + ". Displaying Hospitals near Bangalore location")
                $(".location-specific-hospital").css("background-color", "#FF7800")
            } else {
                $(".location-specific-hospital").css("display", "none")
            }
        }
        if ($("#top").length > 0) {
            var elmnt = document.getElementById("top");
            $("#section-data").css("margin-top", elmnt.offsetHeight)
        }

        await loadData();
        await getLinks();
        await loadGTM();
    });
}

$(async function() {

    $("#for-patient").css("display", "none")
    if (screen.width < 768) {
        $("#user-profile").css("display", "none")
        $("#login-close").css("display", "none")
        var elmnt = document.getElementById("nav-bar");
        $("#navbarCollapse").css("margin-top", -elmnt.offsetHeight)

    } else {
        $("#user-profile").css("display", "none")
        $("#login-close").css("display", "none")
    }

    $("#login-btn").addClass("d-none d-md-block")

    $("#search-desktop").val("");
    $("#search-mobile").val("");
    $('#form-modal').on('hidden.bs.modal', function() {
        $('#form-modal').modal('hide')
        // window.location.href = document.referrer;
        history.back();
    });

    $("#form-modal").on('shown', function() {
        $("#form-modal-city").val($("#user-header-location").text())
    });

    $("body").find(".thank_msg").hide();

    $("#user-header-location").click(function() {
        $.get(BASE_PATH + "getlocation/pincode", function(result, status) {
            try {
                result = JSON.parse(result);
                $("#location-pincode").val(result.pincode)
            } catch (error) {

            }

        });
        $("#location-modal").modal('show')
        $("#location-error").css("display", "none")
        $("#location-spinner").css("display", "none");
    });

    $(".location-pick").click(function() {
        navigator.permissions.query({
                name: 'geolocation'
            })
            .then(function(result) {
                if (result.state == "granted") {
                    $("#location-spinner").css("display", "block");
                    getLocation(true);
                } else if (result.state == "denied") {

                    $(".location-pick").html("Location is blocked for this site. Please enable in settings")
                } else if (result.state == "prompt") {
                    getLocation(true);
                }
            })

    });



    $("#first-progress").css("display", "none")
    $("#body").addClass("d-flex")

    if ($("#top").length > 0) {
        var elmnt = document.getElementById("top");
        $("#section-data").css("margin-top", elmnt.offsetHeight)
    }

    window.onresize = function() {
        var elmnt = document.getElementById("top");
        $("#section-data").css("margin-top", elmnt.offsetHeight)
    }

    var elmnt = document.getElementById("drop-down");
    $(".dropdown-content").css("top", elmnt.offsetHeight)

    getProfile();

    $("#close-btn").click(function(e) {
        $(".navbar-toggler").trigger("click");
    });

    $(".navbar-toggler").click(function(e) {
        if ($(e.currentTarget).attr('aria-expanded') == 'false') {
            $('body').addClass("fixed-position");
            setTimeout(
                function() {
                    $("#navbarCollapse").addClass("shadow-menu");
                }, 150);

        } else {
            $('body').removeClass("fixed-position");
            $("#navbarCollapse").removeClass("shadow-menu");
        }
    });

    $("#logout").click(function(e) {
        $("#login-btn").addClass("d-block")
        $("#user-profile").addClass("d-none")
        deleteProfile();
    });


    $('#file-profile').change(function() {
        preImage = $(".user-profile-image").attr("src")
        var i = $(this).prev('label').clone();
        var file_profile = $('#file-profile')[0].files[0].name;
        // $(this).prev('label').text(file_profile);

        console.log($('#file-profile')[0].files[0].name)
        encodeImageFileAsURL($('#file-profile')[0].files);
    });

    function encodeImageFileAsURL(files) {
        let file = files[0];
        let reader = new FileReader();
        reader.onloadend = function(e) {
            image = event.target.result;
            $("#modal-crop").modal('show')
            $("#user-profile-image-crop").attr("src", image)
            setTimeout(function() {
                const image1 = document.getElementById("user-profile-image-crop")
                cropper = new Cropper(image1, {
                    viewMode: 1, // 0, 1, 2, 3
                    responsive: true,
                    restore: true,
                    center: true,
                    aspectRatio: 4 / 3,
                    crop(event) {
                        canvas = cropper.getCroppedCanvas({
                            width: 512,
                            height: 512
                        });

                        canvas.toBlob(function(blob) {
                            url = URL.createObjectURL(blob);
                            var reader = new FileReader();
                            reader.readAsDataURL(blob);
                            reader.onloadend = function() {
                                var base64data = reader.result;
                                $(".user-profile-image").attr("src", base64data)
                                $("#profile-crop").val(base64data)
                            };
                        });


                    },
                });
            }, 150)
            $(".user-default-image").css("display", "none")
            $(".user-profile-image").css("border-radius", "50%")
            $(".user-profile-image").css("display", "block")

        }
        reader.readAsDataURL(file);
    }

    $("#save-crop").click(function() {
        cropper.destroy();
        $("#modal-crop").modal('hide')
    })

    $('#cancel-crop').click(function() {
        $(".user-profile-image").attr("src", preImage)
        if (preImage == "") {
            $(".user-default-image").css("display", "block")
            $(".user-profile-image").css("display", "none")
        }
        cropper.destroy();
        $("#modal-crop").modal('hide')
    })

    $("#edit-profile-mobile").click(function(e) {
        $("#profile").css("display", "block");
        $("#edit-profile-mobile").removeClass("d-flex")
        $("#edit-profile-mobile").addClass("d-none")
        $("#btn-update-profile").css("display", "block")
        $('#user-first-name').prop('disabled', false);
        $('#user-last-name').prop('disabled', false);
        $('#user-email').prop('disabled', false);
        $('#user-dob').prop('disabled', false);
        $('#user-address').prop('disabled', false);
        $('#user-city').prop('disabled', false);
        $('#user-state').prop('disabled', false);
        $('#user-pincode').prop('disabled', false);
        // updateProfile();
        $('.user-name').css("display", "none")
        $('.control').css('padding', '10px 0px')
    });

    $("#edit-profile-desktop").click(function(e) {
        $("#profile").css("display", "block");
        $("#edit-profile-desktop").removeClass("d-md-flex")
        $("#edit-profile-desktop").addClass("d-md-none")
        $("#btn-update-profile").css("display", "block")
        $('#user-first-name').prop('disabled', false);
        $('#user-last-name').prop('disabled', false);
        $('#user-email').prop('disabled', false);
        $('#user-dob').prop('disabled', false);
        $('#user-address').prop('disabled', false);
        $('#user-city').prop('disabled', false);
        $('#user-state').prop('disabled', false);
        $('#user-pincode').prop('disabled', false);
        $('.user-name').css("display", "none")
        $('.control').css('padding', '10px 0px')
        // updateProfile();
    });

    $("#form-contact-sumbit").submit(function(e) {
        var h = window.location.href;
        var prefix = h.indexOf("www");
        var pre = "";
        if (prefix == -1) {
            pre = "https://";
        } else {
            pre = "https://www.";
        }
        var form = $(e.target);
        var url = BASE_PATH + "contact-us";
        $.ajax({
            type: "POST",
            url: url,
            dataType: "json",
            data: form.serialize(), // serializes the form's elements.
            success: function(data) {
                if (data["status"] == "suc") {
                    $("#btn-contact-sumbit").hide();
                    $("#submit-frm-top").addClass("alert-success");
                    $(form).find(".thank_msg").show();
                    formSuccessSubmit(data);
                } else {
                    $("#btn-contact-sumbit").hide();
                    $("#submit-frm-top").addClass("alert-warning");
                    $(form).find(".thank_msg").html(data["message"])
                    $(form).find(".thank_msg").show();
                }
            }
        });

    });

    $("#form_modal-crm").submit(function(e) {
        e.preventDefault();

        var form = $("#form_modal-crm")

        var url = BASE_PATH + 'crm-save-form'
        $.ajax({
            type: "POST",
            url: url,
            enctype: 'form-data',
            processData: false,
            contentType: false,
            data: new FormData(this),
            success: function(data) {
                data = JSON.parse(data)
                if (data.status) {
                    $(form).find(".frm-submit-bottom").hide();
                    $(form).find("button").hide();
                    $(form).find(".thank_msg").show();
                    formSuccessSubmit(data);
                } else {
                    $(form).find(".frm-submit-bottom").hide();
                    $(form).find(".thank_msg").html("Something went wrong, please try again later.")
                    $(form).find(".thank_msg").show();
                }
            }
        });
    });
});


function formSuccessSubmit(data) {
    var dataObject = {
        'event': 'FormFillSuccess',
        'category': 'LandingPages',
        'label': 'formSuccess',
        'userId': data["userId"],
    };
    setCookie('user-id', data["userId"])
    var ul = getCookie("u-l")
    if (ul != "" && ul.length == 6) {
        // console.log(etlabPush);
        if (typeof dataLayer != 'undefined') {
            dataLayer.push({
                'pincode': ul
            });
        }
    }

    try {
        if (data['newlead'] == "yes") {
            if (typeof dataLayer != 'undefined') {
                dataLayer.push(dataObject);
            }
        }
    } catch (error) {}
}

async function loadGTM() {
    await loadgtm(window, document, 'script', 'dataLayer', 'GTM-M2PNTSR')
}

async function loadgtm(w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({
        'gtm.start': new Date().getTime(),
        event: 'gtm.js'
    });
    var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s),
        dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src =
        '//www.googletagmanager.com/gtm.js?id=' + i + dl;
    f.parentNode.insertBefore(j, f);



    setTimeout(function() {
        try {
            var clientId = getCookie("c-i")
            if (clientId != "") {
                var time = new Date().toLocaleString();
                setCookie("w-l-i-t", time) //last-interaction-time
                setCookie("w-l-i-u", window.location.href) //last-interaction-url
            } else {
                var time = new Date().toLocaleString();
                var client = ga.getAll()[0].get('clientId');
                setCookie("c-i", client) //client-id

                setCookie("w-f-i-t", time) //first-interaction-time
                setCookie("w-f-i-u", window.location.href) //first-interaction-url
            }

            var ul = getCookie("w-u-l")
            if (ul != "" && ul.length == 6) {
                // console.log(etlabPush);
                if (typeof dataLayer != 'undefined') {
                    dataLayer.push({
                        'pincode': ul
                    });
                }
            }
        } catch (e) {

        }

    }, 1000);

}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

async function getProfile() {
    $.get(BASE_PATH + "getProfile", function(result, status) {

        try {
            result = JSON.parse(result)
            if (result.user_name != null) {
                setCookie("logged", "yes")
                $("#userName").html(capitalizeFirstLetter(result.user_name))

                $("#login-btn").removeClass("d-md-block")
                $("#user-profile").addClass("d-none d-md-flex")

                $("#menu-signed").addClass("d-flex")
                $("#menu-sign").addClass("d-none")
                $(".menu-logout").css("display", "block")
                $("#profile").css("display", "none");

                patient_id = result.patient_id;

                if ($('#details-name').length > 0) {
                    $('#details-name').html(result.user_name);
                    $('#details-number').html(result.mobile_no);
                }

                $('.user-name').css("display", "block")
                if ($(".user-name").length > 0) {
                    $('.control').css('padding', '0px')

                    var name = result.user_name.split(" ");
                    var firstLetter = name[0].substring(0, 1);
                    if (name.length > 1 && name[1].length > 1) {
                        firstLetter += " " + name[1].substring(0, 1);
                    }

                    $(".user-default-image").html(firstLetter.toUpperCase())

                    $("#search-mobile").removeClass("d-block")
                    $("#search-mobile").addClass("d-none")
                    $("#btn-update-profile").css("display", "none")
                    $(".user-name").html(capitalizeFirstLetter(result.user_name))
                    $("#patient_id").val(patient_id)
                    $("#user-first-name").val(result.first_name)
                    $("#user-last-name").val(result.last_name)
                    $("#user-email").val(result.email_address)
                    $("#user-dob").val(result.dob)
                    $("#user-address").val(result.address)
                    $("#user-city").val(result.city)
                    $("#user-state").val(result.state)
                    $("#user-pincode").val(result.pincode)

                    $("#edit-profile-desktop").addClass("d-md-flex")
                    $("#edit-profile-desktop").removeClass("d-md-none")
                    $("#edit-profile-mobile").addClass("d-flex")
                    $("#edit-profile-mobile").removeClass("d-none")

                    $('#user-first-name').prop('disabled', true);
                    $('#user-last-name').prop('disabled', true);
                    $('#user-email').prop('disabled', true);
                    $('#user-dob').prop('disabled', true);
                    $('#user-address').prop('disabled', true);
                    $('#user-city').prop('disabled', true);
                    $('#user-state').prop('disabled', true);
                    $('#user-pincode').prop('disabled', true);
                    $(".user-profile-image").css("display", "none")

                    if (result.profile_image != null && result.profile_image.endsWith(".png")) {
                        getMeta(result.profile_image);
                        $(".user-default-image").css("display", "none")
                        $(".user-profile-image").css("display", "block")
                        $(".user-profile-image").css("border-radius", "50%")
                        $(".user-profile-image").attr("src", result.profile_image)
                    }
                }
            } else {
                setCookie("logged", "no")

                $("#menu-signed").addClass("d-none")
                $("#menu-sign").addClass("d-flex")
                $(".menu-logout").css("display", "none")
            }
        } catch (error) {
            setCookie("logged", "no")
        }
    });

}

function getMeta(url) {
    var i = new Image();

    i.onload = function() {
        if (i.width > 512) {
            $(".user-profile-image").css("object-fit", "contain")
        }
    };

    i.src = url;
}

async function deleteProfile() {
    $.get(BASE_PATH + "deleteProfile", function(result, status) {
        // if($(".user-name").length > 0){
        window.location.href = BASE_PATH;
        // }
    });
}

async function updateProfile() {
    $.get(BASE_PATH + "deleteProfile", function(result, status) {
        // if($(".user-name").length > 0){
        window.location.href = BASE_PATH;
        // }
    });
}

$(".form-update-profile").submit(function(e) {

    e.preventDefault(); // avoid to execute the actual submit of the form.

    $.ajax({
        type: "POST",
        url: BASE_PATH + 'updateProfile',
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        data: new FormData(this),
        success: function(data) {
            getProfile();
        }
    });
});

async function error() {
    $(".location-pick").html("location access is blocked or disabled, please enable in browser settings")
    $(".location-pick").css("text-decoration", "none")
    locationLoading = false;
}

const options = {
    enableHighAccuracy: true,
    maximumAge: 30000,
    timeout: 27000
};

function showPosition(position) {
    clearTimeout(timeout);
    if (locationLoading) {
        $.getJSON("https://maps.googleapis.com/maps/api/geocode/json?latlng=" + position.coords.latitude + "," + position.coords.longitude + "&location_type=ROOFTOP&result_type=street_address&key=AIzaSyBdtyFQmJBfdqlLhL-pztNrsPFtuWkHoyE", async function(data) {
            if (data.results.length > 0) {
                var name;
                var pincode;
                for (var i = 0; i < data.results[0].address_components.length; i++) {
                    if (data.results[0].address_components[i].types.length > 0) {
                        for (var k = 0; k < data.results[0].address_components[i].types.length; k++) {
                            if (data.results[0].address_components[i].types[k] == "sublocality_level_1") {
                                name = data.results[0].address_components[i].long_name;
                            } else if (data.results[0].address_components[i].types[k] == "locality") {
                                if (name == null) {
                                    name = data.results[0].address_components[i].long_name;
                                }
                            } else if (data.results[0].address_components[i].types[k] == "administrative_area_level_2") {
                                name = data.results[0].address_components[i].long_name;
                            } else if (data.results[0].address_components[i].types[k] == "postal_code") {
                                pincode = data.results[0].address_components[i].long_name;
                            }
                        }
                        if (pincode != null && name != null) {
                            $("#location-pincode").val(pincode)
                            console.log(name)
                            await updateLocation(pincode, name);
                        }
                    }
                }
            }
        });
    }

}

function getLocation(load_location) {
    if (!locationLoading && load_location) {
        locationLoading = true;
        timeout = setTimeout(async function() {}, 5000);
        if ('geolocation' in navigator) {
            navigator.geolocation.watchPosition(showPosition, error);
        }
    }

}

async function updateLocation(city, name) {
    if (!updating) {
        updating = true;
        if (city == null) {
            city = "Bangalore";
        }
        if (name != null) {
            name = name.replaceAll(" ", "_")
        }
        $.get(BASE_PATH + "updatelocation/" + city + "/" + name + "/" + "pincode", function(result, status) {
            try {
                result = JSON.parse(result);
                locationData = result
                $("#user-header-location").html(result.location)
                $("#user-location-number").val(result.number)
                $("#form-modal-city").val(result.location)
                // $("#call-btn-header-desktop").attr("href","tel:"+result.number)
                // $("#call-btn-header-desktop").html("Speak to a medical expert "+result.number)
                // $("#call-btn-header-mobile").attr("href","tel:"+result.number)
                locationLoading = false;
                $("#location-modal").modal('hide')
                loadData();
                updating = false;
                if ($(".location-specific").length > 0) {
                    $(".location-specific").css("display", "block")
                    if (result.secondary_pincode != null) {
                        $(".location-specific").html("No Doctors found near " + result.location + ". Displaying Doctors near Bangalore location")
                        $(".location-specific").css("background-color", "#FF7800")
                    } else {
                        $(".location-specific").html("Displaying Doctors near " + result.location + " location")
                    }

                }
            } catch (error) {}

        });
    }

}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (90 * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + "; path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function ajaxCallSearch(url) {
    return $.ajax({
        url: url,
        type: "GET",
        dataType: "text",
    });
}

$('#search-desktop').on("keyup input", async function() {
    /* Get input value on change */

    var inputVal = $(this).val();
    var resultDropdown = $("#result-desktop");

    if (preSreachValue != null) {

        if (preSreachValue != inputVal) {
            preSreachValue = inputVal;
            getSearchData(inputVal, resultDropdown);
        }

    } else {
        preSreachValue = inputVal;
        getSearchData(inputVal, resultDropdown);
    }

});

$('#search-mobile').on("keyup input", async function() {
    /* Get input value on change */

    var inputVal = $(this).val();
    var resultDropdown = $("#result-mobile");

    if (preSreachValue != null) {
        if (preSreachValue != inputVal) {
            preSreachValue = inputVal;
            getSearchData(inputVal, resultDropdown);
        }
    } else {
        preSreachValue = inputVal;
        getSearchData(inputVal, resultDropdown);
    }
});

async function getSearchData(inputVal, resultDropdown) {

    if (inputVal.length > 0) {
        resultDropdown.css("display", "flex")
        var progress = '<div id="progress">' +
            '<div class="my-4 d-flex align-items-center justify-content-center">' +
            ' <div class="d-flex spinner-border text-primary" role="status">' +
            ' <span class="sr-only">Loading...</span>' +
            ' </div>' +
            '</div>' +
            ' </div>';
        resultDropdown.html(progress);
        resultDropdown.css("overflow", "none")
        var result = await ajaxCallSearch(BASE_PATH + 'search/' + inputVal)

        if (result.length > 0) {
            resultDropdown.html(result);
            highlight(inputVal, resultDropdown);
        } else {
            resultDropdown.css("display", "none")
            resultDropdown.children().remove();
        }
    } else {
        resultDropdown.css("display", "none")
        resultDropdown.children().remove();
    }
}

function highlight(string, element) {
    var children = $(element).children();
    for (var i = 0; i < children.length; i++) {
        $(children[i]).children().next().each(function() {
            var matchStart = $(this).text().toLowerCase().indexOf("" + string.toLowerCase() + "");
            var matchEnd = matchStart + string.length - 1;
            var beforeMatch = $(this).text().slice(0, matchStart);
            var matchText = $(this).text().slice(matchStart, matchEnd + 1);
            var afterMatch = $(this).text().slice(matchEnd + 1);
            if (matchText != "") {
                $(this).html(beforeMatch + "<b>" + matchText + "</b>" + afterMatch);
            }

        });
    }

}

$(document).on("click", function(e) {
    if ($(e.target).attr("id") == "result-desktop" || $(e.target).parent().attr("id") == "result-desktop" || $(e.target).attr("id") == "search-desktop") {

    } else if ($(e.target).attr("id") == "result-mobile" || $(e.target).parent().attr("id") == "result-mobile" || $(e.target).attr("id") == "search-mobile") {

    } else if ($(e.target).attr("id") == "submit-location-pincode") {

        if (!locationLoading) {
            locationLoading = true;
            var pincode = $("#location-pincode").val()
            if (pincode.length < 6) {
                $("#location-error").css("display", "block")
            } else {
                $("#location-spinner").css("display", "block");
                $.getJSON("https://maps.googleapis.com/maps/api/geocode/json?address=" + pincode + "&result_type=street_address&key=AIzaSyBdtyFQmJBfdqlLhL-pztNrsPFtuWkHoyE", async function(data) {
                    if (data.results.length > 0) {
                        var name;
                        var pincode;
                        for (var i = 0; i < data.results[0].address_components.length; i++) {
                            if (data.results[0].address_components[i].types.length > 0) {
                                for (var k = 0; k < data.results[0].address_components[i].types.length; k++) {
                                    if (data.results[0].address_components[i].types[k] == "sublocality_level_1") {
                                        name = data.results[0].address_components[i].long_name;
                                    } else if (data.results[0].address_components[i].types[k] == "locality") {
                                        if (name == null) {
                                            name = data.results[0].address_components[i].long_name;
                                        }
                                    } else if (data.results[0].address_components[i].types[k] == "administrative_area_level_2") {
                                        if (name == null) {
                                            name = data.results[0].address_components[i].long_name;
                                        }
                                    } else if (data.results[0].address_components[i].types[k] == "postal_code") {
                                        pincode = data.results[0].address_components[i].long_name;
                                    }
                                }

                                if (pincode != null && name != null) {
                                    console.log(name)
                                    $("#location-pincode").val(pincode)
                                    await updateLocation(pincode, name);
                                }

                            }
                        }
                    }
                });
            }
        }
    } else {
        if ($("#result-desktop").is(":visible")) {
            $("#search-desktop").val("");
            $("#result-desktop").css("display", "none")
        } else if ($("#result-mobile").is(":visible")) {
            $("#search-mobile").val("");
            $("#result-mobile").css("display", "none")
        }
    }

});

async function getLinks() {
    var result = await ajaxCallSearch(BASE_PATH + 'getsociallinks')

    if (result != null) {
        result = JSON.parse(result);
        data = result.data

        $(".facebook").on("click", function(e) {
            window.open(data.fb_link, '_blank')
        });
        $(".twitter").on("click", function(e) {
            window.open(data.twitter_link, '_blank')
        });
        $(".instagram").on("click", function(e) {
            window.open(data.insta_link, '_blank')
        });
        $(".linkedin").on("click", function(e) {
            window.open(data.linkedin_link, '_blank')
        });
        $(".youtube").on("click", function(e) {
            window.open(data.youtube_link, '_blank')
        });
    }
    $(".facebook").css("cursor", "pointer")
    $(".twitter").css("cursor", "pointer")
    $(".instagram").css("cursor", "pointer")
    $(".linkedin").css("cursor", "pointer")
    $(".youtube").css("cursor", "pointer")
}

function ajaxCallScript(url) {
    return $.ajax({
        url: url,
        type: "GET",
        dataType: "script",
    });
}

function ajaxCallCss(url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = url;
    link.media = 'all';
    head.appendChild(link);
}

function ajaxCall(url) {
    return $.ajax({
        url: url,
        type: "GET",
        dataType: "text",
    });
}

async function loadData() {

    try {
        await getBanner();
        await getStats();
        await getTestimonials();
        await getDoctorsHome();
        await getHospitalsHome();

    } catch (error) {}

    try {
        await getDoctors();
    } catch (error) {}

    try {
        await getSurgeryDetails();
    } catch (error) {}

    try {
        await getServices();
    } catch (error) {}

    try {
        await getHospitals();
    } catch (error) {}

    try {
        await getAppointmentDetails();
    } catch (error) {}

    try {
        await getHospitalDetail();
    } catch (error) {}
}

async function loginCrm(phone_number, city) {
    var url = BASE_PATH + 'crm-login-form'
    return $.post(url, {
        phone_number: phone_number,
        name: "Medisync Patient",
        channel: "Website",
        sub_category: "Login",
        city: city,
        category: "Lead",
        parameteres: window.location.href
    });
}