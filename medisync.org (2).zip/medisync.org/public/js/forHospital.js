var goback = 0;

window.onload = async function() {
    $("#data-content").removeClass("d-none")
    $("#data-content").addClass("d-flex")
    $("#progress").remove();

    window.addEventListener('popstate', function(event) {
        // window.location.href = document.referrer;
        console.log(goback)

    });



    await bannerSlide();
    await getHospitals();
    await news();
    setTimeout(function() {
        scroll();
    }, 300)
};

function bannerSlide() {
    return $('.banner-slide').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        centerMode: false,
        arrows: false,
        infinite: true,
        rows: 0,
        dots: false,
        pauseOnHover: true,
    });
}

function news() {
    return $('.news-section').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: false,
        centerMode: false,
        arrows: false,
        infinite: false,
        rows: 0,
        dots: true,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
            }
        }]
    });
}

var load = true;

$(async function() {

    var userDestination = getCookie("u-d")
    $("#for-patient").css("display", "block")
    $(".header-dropdown-profile").css("display", "none")
    $("#login-close").css("display", "none")
    $("#login-btn").removeClass("d-md-block")
    $("#user-header-location").css("display", "none")
    $(".search-box-div").removeClass("d-md-block")
    $(".search-box-div").removeClass("d-flex")
    $(".search-box-div").addClass("d-none")
    $("#call-btn-header-desktop").html("Speak to us 080 6193 3218")

    if (userDestination == 'undefined' || userDestination == '') {
        $("#modal-select").modal('show')
    }

    $("#first-progress").css("display", "none")
    $("#body").addClass("d-flex")

    if ($("#top").length > 0) {
        var elmnt = document.getElementById("top");
        $("#section-data").css("margin-top", elmnt.offsetHeight)
    }

    $("#hospital").click(function() {
        setCookie("u-d", "hospital")
        $("#modal-select").modal('hide')
    })

    $("#patient").click(function() {
        setCookie("u-d", "patient")
        window.location.href = BASE_PATH + "for-patient";
        $("#modal-select").modal('hide')
    })

    $("#doctor").click(function() {
        setCookie("u-d", "doctor")
        $("#modal-select").modal('hide')
    })

    $("#enquire-contact-sumbit").submit(function(e) {
        var h = window.location.href;
        var prefix = h.indexOf("www");
        var pre = "";
        if (prefix == -1) {
            pre = "https://";
        } else {
            pre = "https://www.";
        }
        var form = $(e.target);
        var url = BASE_PATH + "b2b-enquire";
        $.ajax({
            type: "POST",
            url: url,
            dataType: "json",
            data: form.serialize(), // serializes the form's elements.
            success: function(data) {
                if (data["status"] == "suc") {
                    $("#modal-enquire").modal('hide');
                    $("#modal-result").modal('show');
                } else {
                    $("#btn-contact-sumbit").hide();
                    $("#submit-frm-top").addClass("alert-warning");
                    $(form).find(".thank_msg").html(data["message"])
                    $(form).find(".thank_msg").show();
                }
            }
        });

    });

    $('#associated-tab').click(function() {
        if (load) {
            // $('.associated-hos').slick('refresh');
            setTimeout(function() {
                hos();
            }, 200)
            //
        }

    })

    var lastScrollTop = 0;

    window.onscroll = function() {
        var url = window.location.href;
        var st = window.pageYOffset || document.documentElement.scrollTop; // Credits: "https://github.com/qeremy/so/blob/master/so.dom.js#L426"
        if (st > lastScrollTop) {
            if (isScrolledIntoView(document.getElementById("vision-mission"))) {
                goback++;
                window.history.replaceState("team1", "team1", "vision-mission");
            } else if (isScrolledIntoView(document.getElementById("services"))) {
                goback++;
                window.history.replaceState("team2", "team1", "medisync-services");
            } else if (isScrolledIntoView(document.getElementById("hospitals"))) {
                goback++;
                window.history.replaceState("team3", "team1", "network-of-hospitals");
            } else if (isScrolledIntoView(document.getElementById("credo"))) {
                goback++;
                window.history.replaceState("team4", "team1", "medisync-credo");
            } else if (isScrolledIntoView(document.getElementById("why-medisync"))) {
                goback++;
                window.history.replaceState("team5", "team1", "why-medisync");
            } else if (isScrolledIntoView(document.getElementById("our-team"))) {
                goback++;
                window.history.replaceState("team6", "team1", "meet-our-team");
            } else if (isScrolledIntoView(document.getElementById("success-stories"))) {
                goback++;
                window.history.replaceState("team7", "team1", "success-stories");
            } else if (isScrolledIntoView(document.getElementById("news"))) {
                goback++;
                window.history.replaceState("team8", "team1", "in-the-news");
            } else if (isScrolledIntoView(document.getElementById("our-investor"))) {
                goback++;
                window.history.replaceState("team9", "team1", "our-investor");
            }
        } else {
            if (isScrolledIntoViewup(document.getElementById("vision-mission"))) {
                goback++;
                window.history.replaceState("team1", "team1", "vision-mission");
            } else if (isScrolledIntoViewup(document.getElementById("services"))) {
                goback++;
                window.history.replaceState("team2", "team1", "medisync-services");
            } else if (isScrolledIntoViewup(document.getElementById("hospitals"))) {
                goback++;
                window.history.replaceState("team3", "team1", "network-of-hospitals");
            } else if (isScrolledIntoViewup(document.getElementById("credo"))) {
                goback++;
                window.history.replaceState("team4", "team1", "medisync-credo");
            } else if (isScrolledIntoViewup(document.getElementById("why-medisync"))) {
                goback++;
                window.history.replaceState("team5", "team1", "why-medisync");
            } else if (isScrolledIntoViewup(document.getElementById("our-team"))) {
                goback++;
                window.history.replaceState("team6", "team1", "meet-our-team");
            } else if (isScrolledIntoViewup(document.getElementById("success-stories"))) {
                goback++;
                window.history.replaceState("team7", "team1", "success-stories");
            } else if (isScrolledIntoViewup(document.getElementById("news"))) {
                goback++;
                window.history.replaceState("team8", "team1", "in-the-news");
            } else if (isScrolledIntoViewup(document.getElementById("our-investor"))) {
                goback++;
                window.history.replaceState("team9", "team1", "our-investor");
            }
        }
        lastScrollTop = st <= 0 ? 0 : st;

    };


});

async function getHospitals() {
    $.ajax({
        url: BASE_PATH + 'hospitals-all' + "?hospital_id=all&use_location=true",
        type: "GET",
        dataType: "text",
        success: async function(result) {
            $("#nav-tabContent").html(result);
            $("#progress-2").css("display", "flex")
            $(".associated-hos").css("display", "none")
            await hospitalSlider();
            await getLinks();
            await loadGTM();
        },
        error: function(error) {}
    });
}

function hospitalSlider() {
    $('.managed-hos').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: false,
        centerMode: false,
        arrows: true,
        infinite: false,
        rows: 0,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
            }
        }, {
            breakpoint: 992,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                arrows: false,
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                arrows: false,
            }
        }, {
            breakpoint: 525,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
                arrows: false,
            }
        }, ]
    });




    // setTimeout(function() {
    //     $('#associated-tab').click()
    //     setTimeout(function() {
    //         $('#managed-tab').click()
    //         load = true;
    //     }, 700)
    // }, 500)



}

async function hos() {

    await $('.associated-hos').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: false,
        centerMode: false,
        arrows: true,
        infinite: false,
        rows: 0,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
            }
        }, {
            breakpoint: 992,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                arrow: false
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                arrows: false,
            }
        }, {
            breakpoint: 525,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
                arrows: false,
            }
        }, ]
    });


    $("#progress-2").css("display", "none")
    $(".associated-hos").css("display", "block")
    load = false;
}

// function setCookie(cname, cvalue, exdays) {
//     var d = new Date();
//     d.setTime(d.getTime() + (exdays * 60 * 1000));
//     var expires = "expires=" + d.toUTCString();
//     document.cookie = cname + "=" + cvalue + ";" + expires + "; path=/";
// }
//
// function getCookie(cname) {
//     var name = cname + "=";
//     var ca = document.cookie.split(';');
//     for (var i = 0; i < ca.length; i++) {
//         var c = ca[i];
//         while (c.charAt(0) == ' ') {
//             c = c.substring(1);
//         }
//         if (c.indexOf(name) == 0) {
//             return c.substring(name.length, c.length);
//         }
//     }
//     return "";
// }

function isScrolledIntoView(el) {
    var rect = el.getBoundingClientRect();
    var elemTop = rect.top - parseInt($("#section-data").css("margin-top"));
    var elemBottom = rect.bottom - (parseInt($("#section-data").css("margin-top")) + 100);
    // Only completely visible elements return true:
    // var isVisible = (elemTop >= 0) && (elemBottom <= window.innerHeight);
    // console.log("top="+elemTop)
    // console.log("bottom="+elemBottom)
    try {
        var isVisible = (elemTop <= 50) && (elemBottom >= 0)
    } catch (err) {}
    // Partially visible elements return true:
    //isVisible = elemTop < window.innerHeight && elemBottom >= 0;
    return isVisible;
}

function isScrolledIntoViewup(el) {
    var rect = el.getBoundingClientRect();
    var elemTop = rect.top - parseInt($("#section-data").css("margin-top"));
    var elemBottom = rect.bottom - parseInt($("#section-data").css("margin-top"));

    // Only completely visible elements return true:
    var isVisible = (elemTop >= 0) && (elemBottom <= window.innerHeight);
    // Partially visible elements return true:
    //isVisible = elemTop < window.innerHeight && elemBottom >= 0;
    return isVisible;
}

function scroll() {
    var url = window.location.href;
    if (url.includes('vision-mission')) {
        scrollToTargetAdjusted("vision-mission");
    } else if (url.includes('medisync-services')) {
        scrollToTargetAdjusted("services");
    } else if (url.includes('network-of-hospitals')) {
        scrollToTargetAdjusted("hospitals");
    } else if (url.includes('medisync-credo')) {
        scrollToTargetAdjusted("credo");
    } else if (url.includes('why-medisync')) {
        scrollToTargetAdjusted("why-medisync");
    } else if (url.includes('meet-our-team')) {
        scrollToTargetAdjusted("our-team");
    } else if (url.includes('success-stories')) {
        scrollToTargetAdjusted("success-stories");
    } else if (url.includes('in-the-news')) {
        scrollToTargetAdjusted("news");
    } else if (url.includes('our-investor')) {
        scrollToTargetAdjusted("our-investor");
    }
}

function scrollToTargetAdjusted(element) {

    var element = document.getElementById(element);
    var headerOffset = 0;
    var elementPosition = element.offsetTop - parseInt($("#section-data").css("margin-top"));
    var offsetPosition = elementPosition - headerOffset;

    window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
    });
}